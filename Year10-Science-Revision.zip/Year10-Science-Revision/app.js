(function(){
const SUBJ = {bio:"Biology", chem:"Chemistry", phys:"Physics"};
const KEY = "cgs-sem2-ticks";
const ticks = JSON.parse(localStorage.getItem(KEY) || "{}");
const view = document.getElementById("view");
const esc = s=>s.replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));

// Topic cards: core Biology split by booklet/strand, everything else one card per subject.
const GROUPS = [];
["core","ext"].forEach(level=>{
  Object.keys(SUBJ).forEach(k=>{
    const list = DATA[level][k]; if (!list.length) return;
    if (level==="core" && k==="bio"){
      [...new Set(list.map(t=>t.group))].forEach(g=>GROUPS.push({level,k,g,title:g.replace(/\s*\(.*\)/,"").replace("Genetics · ","Genetics: "),sub:g.includes("(")?g.match(/\((.*)\)/)[1]:"Natural selection, speciation, trees",items:list.filter(t=>t.group===g)}));
    } else {
      GROUPS.push({level,k,title:SUBJ[k],sub:[...new Set(list.map(t=>t.group))].join(" · "),items:list});
    }
  });
});
GROUPS.forEach((g,i)=>{ g.slug=g.level+"-"+i; g.n=String(GROUPS.filter(x=>x.level===g.level).indexOf(g)+1).padStart(2,"0"); });

const tid = (level,tp)=>level+"-"+tp.id;
const objs = g=>g.items.flatMap(tp=>tp.checks.map((c,j)=>tid(g.level,tp)+"-"+j));
const done = keys=>keys.filter(k=>ticks[k]).length;

function card(g){
  const o=objs(g), d=done(o), cards=g.items.reduce((a,t)=>a+t.cards.length,0);
  return `<a class="tcard ${g.k}" href="#${g.slug}">
    ${g.level==="ext"?`<span class="pill">Ext</span>`:""}
    <span class="num">${g.n}</span><b>${esc(g.title)}</b><span class="s">${esc(g.sub)}</span>
    <span class="track"><i style="width:${o.length?d/o.length*100:0}%"></i></span>
    <span class="meta">${d}/${o.length} objectives · ${g.items.length} topic${g.items.length>1?"s":""} · ${cards} flashcards</span></a>`;
}

const EXAM_DAY = new Date(2026,10,17);
function daysLeft(){ const t=new Date(); t.setHours(0,0,0,0); return Math.max(0,Math.round((EXAM_DAY-t)/864e5)); }

function header(active){
  const all = GROUPS.flatMap(objs), d = done(all), n = daysLeft();
  const pill = (href,label,on,cls="")=>`<a class="${on?"on":""} ${cls}" href="${href}">${label}</a>`;
  return `
    <div class="examcards">
      <a class="ecard next" href="exams.html#core2025"><div class="l"><div class="k">Exam 1</div><h2>Science</h2><div class="d">Tue 17 Nov · 90 min (past papers) · Biology, Chemistry, Physics</div></div><div class="days">${n}<small>days</small></div></a>
      <a class="ecard" href="exams.html#ext2025"><div class="l"><div class="k">Exam 2</div><h2>Science Extension</h2><div class="d">Tue 17 Nov · 30 min (past papers) · Chemistry + Evolution</div></div><div class="days">${n}<small>days</small></div></a>
    </div>
    <div class="overall"><span class="track"><i style="width:${all.length?d/all.length*100:0}%"></i></span><span>${d} / ${all.length} objectives ticked</span></div>
    <nav class="pills">${pill("#","Overview",active==="home")}
      ${GROUPS.filter(g=>g.level==="core").map(g=>pill("#"+g.slug,esc(g.title),active===g.slug)).join("")}
      <span class="sep"></span>
      ${GROUPS.filter(g=>g.level==="ext").map(g=>pill("#"+g.slug,"Ext "+esc(g.title),active===g.slug,"ext")).join("")}
      <span class="sep"></span>${pill("exams.html","Practice exams",false)}</nav>`;
}

function home(){
  view.innerHTML = `<div class="wrap">${header("home")}
    <div class="hero"><h1><span class="dot"></span>Overview</h1><div class="s">Core + Extension · Biology, Chemistry, Physics</div></div>
    <div class="note"><b>What's examined:</b> every objective on your 2026 Sem 2 Exam Objectives checklist, covering genetics (cells, DNA, mitosis and meiosis, inheritance), evolution, rates of reaction and thermal energy. Practise <b>drawing</b> labelled mitosis and meiosis stages, Punnett squares, pedigree charts, phylogenetic trees and rate graphs. Exam lengths come from the 2022–2025 papers, so check your session time on the timetable.</div>

    <h3 class="h">Command words</h3>
    <div class="cmds">
      <div><b>Identify</b>Name the thing or pick out the answer. No explanation needed.</div>
      <div><b>Describe</b>Say what happens or what something is like.</div>
      <div><b>Explain</b>Say what happens and why. Link cause to effect with "because".</div>
      <div><b>Justify</b>Back up your answer with evidence from the data or diagram.</div>
    </div>

    <h3 class="h">Pick a topic</h3>
    <div class="tgrid">${GROUPS.filter(g=>g.level==="core").map(card).join("")}
      <a class="tcard special" href="exams.html"><span class="num">✦</span><b>Practice exams</b><span class="s">2022–2025 Core &amp; Extension papers</span><span class="meta">Timed · auto-marked · redrawn diagrams</span></a></div>

    <h3 class="h">Extension topics</h3>
    <div class="tgrid">${GROUPS.filter(g=>g.level==="ext").map(card).join("")}</div>

    <h3 class="h">How the Extension list was worked out</h3>
    <ul class="notes-list">
      <li><b>Genetic drift</b> and <b>gene flow</b> are marked EXT on your checklist.</li>
      <li>The checklist says bold keywords are extension only, but the bold formatting didn't come through in your files.</li>
      <li>The other Extension topics come from the Extension past papers and are tagged with where they came from. Check them with your teacher.</li>
    </ul>
    <div class="foot">Built from your 2026 Sem 2 Exam Objectives checklist and the 2022–2025 Semester 2 papers. Your ticks are saved in this browser.</div>
  </div>`;
}

function group(g){
  const o=objs(g), d=done(o);
  view.innerHTML = `<div class="wrap">${header(g.slug)}
    <div class="hero"><h1><span class="dot" style="background:${g.level==="ext"?"var(--ext)":"var(--acc)"}"></span>${esc(g.title)}</h1><div class="s">${g.level==="core"?"Core":"Extension"} · ${esc(g.sub)} · ${g.items.length} topic${g.items.length>1?"s":""}</div>
      <div class="tprog bar2"><span class="track"><i id="gp" style="width:${o.length?d/o.length*100:0}%"></i></span><span id="gt">${d}/${o.length} objectives</span></div></div>
    <div class="subj ${g.k}">${g.items.map((tp,i)=>topicHTML(g.level,tp,i)).join("")}</div>
  </div>`;
  view.querySelectorAll(".checklist input").forEach(c=>{ if(ticks[c.dataset.k]) c.checked=true; });
}

function search(q){
  const hits=[]; GROUPS.forEach(g=>g.items.forEach(tp=>{ const txt=(tp.title+" "+tp.html+" "+tp.checks.join(" ")+" "+tp.kw.join(" ")+" "+tp.cards.flat().join(" ")).replace(/<[^>]+>/g," ").toLowerCase(); if(txt.includes(q)) hits.push([g,tp]); }));
  view.innerHTML = `<div class="wrap">${header("")}
    <div class="hero"><h1><span class="dot"></span>“${esc(q)}”</h1><div class="s">${hits.length} matching topic${hits.length===1?"":"s"}</div></div>
    ${hits.length?hits.map(([g,tp],i)=>`<div class="subj ${g.k}">${topicHTML(g.level,tp,i)}</div>`).join(""):`<div class="empty">Nothing found. Try a different keyword.</div>`}</div>`;
  view.querySelectorAll(".checklist input").forEach(c=>{ if(ticks[c.dataset.k]) c.checked=true; });
}

function topicHTML(level,tp,i){
  const id=tid(level,tp), d=tp.checks.filter((c,j)=>ticks[id+"-"+j]).length;
  return `<details class="topic ${level==="ext"?"isext":""}" id="${id}" ${i===0?"open":""}>
    <summary><span class="n">${String(i+1).padStart(2,"0")}</span><h3>${tp.title}</h3><span class="n meta">${tp.group}${tp.src?" · "+tp.src:""}</span><span class="cnt" data-t="${id}">${d}/${tp.checks.length}</span><span class="chev">▸</span></summary>
    <div class="body">
      <div class="ptabs">
        <button class="on" data-p="notes">Notes</button>
        <button data-p="check">Checklist <small>${tp.checks.length}</small></button>
        <button data-p="cards">Flashcards <small>${tp.cards.length}</small></button>
        <button data-p="kw">Keywords <small>${tp.kw.length}</small></button>
      </div>
      <div class="pane" data-p="notes">${tp.html}</div>
      <div class="pane hide" data-p="check"><ul class="checklist">${tp.checks.map((c,j)=>{const ck=id+"-"+j;return `<li class="${ticks[ck]?"done":""}"><input type="checkbox" data-k="${ck}" data-t="${id}"><span>${esc(c)}</span></li>`}).join("")}</ul></div>
      <div class="pane hide" data-p="cards"><p class="hint">Tap a card to flip it.</p><div class="cards">${tp.cards.map(([q,a])=>`<div class="card"><div class="in"><div class="f">${q}</div><div class="b">${a}</div></div></div>`).join("")}</div></div>
      <div class="pane hide" data-p="kw"><div class="kw">${tp.kw.map(w=>`<span class="${tp.ekw?"e":""}">${w}</span>`).join("")}</div></div>
    </div></details>`;
}

function route(){
  const h=location.hash.slice(1), g=GROUPS.find(x=>x.slug===h);
  document.getElementById("q").value="";
  g ? group(g) : home();
  window.scrollTo(0,0);
}
window.addEventListener("hashchange",route);

view.addEventListener("change",e=>{
  const c=e.target; if(!c.dataset.k) return;
  ticks[c.dataset.k]=c.checked; localStorage.setItem(KEY,JSON.stringify(ticks));
  c.parentElement.classList.toggle("done",c.checked);
  const boxes=[...view.querySelectorAll(`.checklist input[data-t="${c.dataset.t}"]`)];
  const cnt=view.querySelector(`.cnt[data-t="${c.dataset.t}"]`); if(cnt) cnt.textContent=`${boxes.filter(x=>x.checked).length}/${boxes.length}`;
  const all=[...view.querySelectorAll(".checklist input")], d=all.filter(x=>x.checked).length;
  const gp=document.getElementById("gp"); if(gp){ gp.style.width=d/all.length*100+"%"; document.getElementById("gt").textContent=`${d}/${all.length} objectives`; }
});
view.addEventListener("click",e=>{
  const c=e.target.closest(".card"); if(c){c.classList.toggle("flip");return;}
  const b=e.target.closest(".ptabs button"); if(!b) return;
  const body=b.closest(".body");
  body.querySelectorAll(".ptabs button").forEach(x=>x.classList.toggle("on",x===b));
  body.querySelectorAll(".pane").forEach(p=>p.classList.toggle("hide",p.dataset.p!==b.dataset.p));
});
let st; document.getElementById("q").addEventListener("input",e=>{
  clearTimeout(st); const q=e.target.value.trim().toLowerCase();
  st=setTimeout(()=>{ if(q.length>=2) search(q); else if(!q) route(); },200);
});

document.getElementById("theme").addEventListener("click",()=>{
  const t=document.documentElement.dataset.theme==="dark"?"light":"dark";
  document.documentElement.dataset.theme=t; localStorage.setItem("cgs-sem2-theme",t);
});

route();
})();
