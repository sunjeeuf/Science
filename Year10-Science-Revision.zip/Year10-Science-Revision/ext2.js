DATA.ext.chem.push(
{id:"energy", title:"Energy profiles, ΔH & activation energy", group:"Reactions & Energy", src:"From extension papers",
checks:[
 "Interpret an energy-profile diagram: reactants, products, activation energy (Ea) and ΔH.",
 "Classify reactions as exothermic (ΔH negative) or endothermic (ΔH positive).",
 "Work out the energy profile for the reverse reaction.",
 "Explain how a catalyst lowers activation energy."
],
html:`
<ul class="notes">
<li><b>ΔH = H(products) − H(reactants).</b> A negative ΔH is <b>exothermic</b> (energy released, products lower than reactants). A positive ΔH is <b>endothermic</b> (energy absorbed, products higher).</li>
<li><b>Activation energy (Ea)</b> is the height of the peak above the <i>reactants</i>: the minimum energy needed for a successful collision.</li>
<li>A <b>catalyst</b> (in living things, an <b>enzyme</b>) gives a lower peak. ΔH doesn't change.</li>
<li><b>Reverse reaction:</b> the products and reactants swap places, so ΔH flips sign. The reverse Ea = peak − old product energy.</li>
</ul>
<h4>Worked example (from the extension paper)</h4>
<p>Reactants are at 50 kJ mol⁻¹, the peak is at 100 and the products are at 40.</p>
<ul class="notes"><li>ΔH = 40 − 50 = <b>−10 kJ mol⁻¹</b>, so it's exothermic. Ea (forward) = 100 − 50 = <b>50 kJ mol⁻¹</b>.</li>
<li>Reverse: the final product energy is 50 and ΔH = <b>+10</b>, so the answer is <b>B</b>. Ea (reverse) = 100 − 40 = 60 kJ mol⁻¹.</li></ul>`,
kw:["enthalpy","ΔH","exothermic","endothermic","activation energy","energy profile","catalyst","enzyme"], ekw:true,
cards:[["Sign of ΔH for exothermic?","Negative: energy is released."],["Where do you measure Ea from?","From the reactants up to the peak."],["Does a catalyst change ΔH?","No. It only lowers Ea."]]},

{id:"atoms", title:"Atoms, ions & isotopes", group:"Chemical Foundations", src:"From extension papers",
checks:[
 "Work out the protons, neutrons and electrons of atoms and ions from the mass number and charge.",
 "Name and write formulas for ionic compounds (including polyatomic ions)."
],
html:`
<ul class="notes">
<li>Protons = atomic number. Neutrons = mass number − protons. Electrons = protons − charge.</li>
<li>Mg²⁺ (mass number 24) has 12 p, 12 n and <b>10 e</b>. Cl⁻ (mass number 36 in the paper) has 17 p, 19 n and <b>18 e</b>.</li>
<li>To write ionic formulas, balance the charges so the total is zero. Use brackets around a polyatomic ion when you need more than one of it.</li>
</ul>
<table><tr><th>Name</th><th>Formula</th><th>Ions</th></tr>
<tr><td>Calcium sulfate</td><td>CaSO₄</td><td>Ca²⁺, SO₄²⁻</td></tr>
<tr><td>Zinc oxide</td><td>ZnO</td><td>Zn²⁺, O²⁻</td></tr>
<tr><td>Copper(II) hydroxide</td><td>Cu(OH)₂</td><td>Cu²⁺, 2 × OH⁻</td></tr>
<tr><td>Sodium carbonate</td><td>Na₂CO₃</td><td>2 × Na⁺, CO₃²⁻</td></tr></table>`,
kw:["proton","neutron","electron","ion","mass number","polyatomic ion"], ekw:true,
cards:[["Electrons in Mg²⁺?","10."],["Formula of sodium carbonate?","Na₂CO₃."],["How do you find neutrons?","Mass number − atomic number."]]},

{id:"hydro", title:"Hydrocarbons: alkanes & alkenes", group:"Organic Chemistry", src:"From extension papers",
checks:[
 "Identify and name simple alkanes and alkenes from structural diagrams."
],
html:`
<ul class="notes">
<li><b>Alkanes</b> have only C–C single bonds (saturated), with general formula CₙH₂ₙ₊₂. Example: <b>butane C₄H₁₀</b>, CH₃–CH₂–CH₂–CH₃.</li>
<li><b>Alkenes</b> have at least one C=C double bond (unsaturated), with general formula CₙH₂ₙ. Example: <b>but-1-ene C₄H₈</b>, CH₂=CH–CH₂–CH₃.</li>
<li>Prefixes by number of carbons: meth- 1, eth- 2, prop- 3, but- 4, pent- 5, hex- 6. In "but-1-ene" the number tells you the double bond starts at carbon 1.</li>
</ul>`,
kw:["alkane","alkene","saturated","unsaturated","butane","but-1-ene"], ekw:true,
cards:[["Alkane general formula?","CₙH₂ₙ₊₂."],["Difference between an alkane and an alkene?","An alkene has a C=C double bond."]]}
);

DATA.ext.phys.push(
{id:"practical", title:"Practical skills: balloon rocket & graphing", group:"Forces & Data Analysis", src:"From past papers (not on checklist)",
checks:[
 "Plot experimental data on a graph with a title, labelled axes and units, a sensible scale and a line of best fit.",
 "Identify the independent, dependent and controlled variables, and spot outliers in data."
],
html:`
<p>The physics short-answer question is a balloon rocket on a string. Mass is added (20–160 g) and the travel time is recorded.</p>
<ul class="notes">
<li><b>Independent variable</b> (what you change) is the added mass, and it goes on the x-axis. The <b>dependent</b> variable (what you measure) is the travel time, on the y-axis.</li>
<li><b>Controlled variables:</b> the same balloon, the same inflation, the same string length and tension.</li>
<li><b>Trend:</b> more mass means a longer travel time. The rocket's thrust is unchanged but there's more mass to accelerate (Newton's 2nd law, a = F/m), so acceleration is lower.</li>
<li><b>Outlier check:</b> the 120 g reading (1.75 s) sits close to the 100 g reading (1.70 s). Point out anything that breaks the trend.</li>
<li>Draw a smooth line or curve of best fit. Don't join the dots.</li>
</ul>
<div class="tip"><b>Heads up</b> This topic came from the past exam papers. It isn't listed on your Sem 2 checklist, so ask your teacher if it's in scope.</div>`,
kw:["independent variable","dependent variable","controlled variable","line of best fit","Newton's second law"], ekw:true,
cards:[["Which variable goes on the x-axis?","The independent variable (the one you change)."],["Why does a heavier rocket take longer?","Same force, more mass, so less acceleration (a = F/m)."]]}
);
