DATA.core.bio.push(
{id:"inherit-mut", title:"Gene vs chromosomal mutations & karyotypes", group:"Genetics · Inheritance (Booklet 2)",
checks:[
 "Recall that a mutation is a change in DNA at the gene level (e.g. cystic fibrosis, Huntington's disorder, diabetes) or at the chromosomal level (e.g. Down syndrome).",
 "Use karyotypes to determine chromosomal-level mutations."
],
html:`
<ul class="notes">
<li><b>Gene-level mutation:</b> a change in the bases of one gene. Examples are cystic fibrosis, Huntington's disorder, sickle-cell anaemia and some forms of diabetes.</li>
<li><b>Chromosomal-level mutation:</b> a change in the number or structure of whole chromosomes. Examples are <b>Down syndrome</b> (trisomy 21, 3 copies of chromosome 21) and <b>Klinefelter syndrome</b> (XXY).</li>
<li>A <b>karyotype</b> is a photo of all of a cell's chromosomes arranged in numbered pairs, 1–22 (<b>autosomes</b>) plus the sex chromosomes.</li>
</ul>
<div class="tip"><b>Reading a karyotype</b> Count every pair. A normal karyotype has 46. Look for any pair that has 3 copies (a trisomy) or only 1. Then check the sex chromosomes: XX is female, XY is male.</div>
<div class="exam"><b>From past papers</b> One karyotype shows three copies of chromosome 8 plus XY: male, 47 chromosomes, trisomy 8. Another shows XXY, which is Klinefelter syndrome.</div>`,
kw:["mutation","karyotype","autosome","genetic disorder","trisomy"],
cards:[["Down syndrome karyotype?","Trisomy 21: 47 chromosomes."],["Klinefelter syndrome?","XXY sex chromosomes: a male with 47 chromosomes."],["Gene vs chromosomal mutation?","A gene mutation changes bases in one gene. A chromosomal mutation changes the number or structure of whole chromosomes."]]},

{id:"sex", title:"Sex determination & acquired vs inherited traits", group:"Genetics · Inheritance (Booklet 2)",
checks:[
 "Explain how birth sex is determined (2 haploid gametes join to form a diploid zygote).",
 "Use karyotypes to determine sex.",
 "Distinguish between an acquired trait and an inherited trait and state some examples."
],
html:`
<ul class="notes">
<li>Females are <b>XX</b> and every egg carries an X. Males are <b>XY</b>, and a sperm carries either an X or a Y.</li>
<li>So the <b>sperm decides birth sex</b>: X sperm + X egg gives XX (female), and Y sperm + X egg gives XY (male). The chance of each is 50%.</li>
<li><b>Inherited traits</b> are coded in DNA and passed on, e.g. eye colour, blood type, dimples, attached earlobes.</li>
<li><b>Acquired traits</b> develop during life and are <b>not</b> passed on in DNA, e.g. scars, muscles from training, a language you speak, dyed hair.</li>
<li>Birth sex (chromosomes) is different from <b>gender identity</b>, which is a person's internal sense of self.</li>
</ul>
<div class="exam"><b>From past papers</b> A multiple-choice question asks which pairing is female XX / male XY (answer D).</div>`,
kw:["inheritance","trait","acquired trait","inherited trait","variation","autosome","gender identity","karyotype","haploid","diploid","zygote","gametes"],
cards:[["Which parent determines birth sex?","The father: the sperm carries either an X or a Y."],["Example of an acquired trait?","A scar, built muscle, or a learned skill. None are passed on."]]},

{id:"crosses", title:"Punnett squares: monohybrid, sex-linked & codominant", group:"Genetics · Inheritance (Booklet 2)",
checks:[
 "Draw a genetic diagram, including a Punnett square, to show the outcome of a monohybrid cross.",
 "Draw a genetic diagram for sex-linked inheritance (e.g. colour blindness).",
 "Draw a genetic diagram for codominant inheritance.",
 "Calculate genotype and phenotype outcomes as a ratio, a percentage and a fraction (e.g. cystic fibrosis, Huntington's disorder, colour blindness)."
],
html:`
<table><tr><th>Term</th><th>Meaning</th></tr>
<tr><td>Allele</td><td>A different version of a gene (e.g. the gene is eye colour, an allele is blue).</td></tr>
<tr><td>Genotype / phenotype</td><td>The alleles you have (Bb) / the trait you show (brown eyes).</td></tr>
<tr><td>Homozygous / heterozygous</td><td>Two identical alleles (BB or bb) / two different alleles (Bb).</td></tr>
<tr><td>Dominant / recessive</td><td>Shows whenever it's present (capital letter) / only shows when homozygous (bb).</td></tr></table>
<h4>Monohybrid: Bb × Bb</h4>
<table style="width:auto"><tr><th></th><th>B</th><th>b</th></tr><tr><th>B</th><td>BB</td><td>Bb</td></tr><tr><th>b</th><td>Bb</td><td>bb</td></tr></table>
<p>The genotype ratio is 1 BB : 2 Bb : 1 bb. The phenotype is 3 dominant : 1 recessive, which is 75% / ¾ dominant and 25% / ¼ recessive.</p>
<h4>Sex-linked (X-linked recessive): colour blindness</h4>
<p>The allele sits on the X chromosome, so write it as a superscript: X<sup>B</sup> is normal and X<sup>b</sup> is colour blind. Here a carrier mother X<sup>B</sup>X<sup>b</sup> has children with a normal father X<sup>B</sup>Y.</p>
<table style="width:auto"><tr><th></th><th>X<sup>B</sup></th><th>Y</th></tr><tr><th>X<sup>B</sup></th><td>X<sup>B</sup>X<sup>B</sup></td><td>X<sup>B</sup>Y</td></tr><tr><th>X<sup>b</sup></th><td>X<sup>B</sup>X<sup>b</sup> carrier</td><td>X<sup>b</sup>Y colour blind</td></tr></table>
<p>Each child has a ¼ (25%) chance of being colour blind, and all of those will be sons. Half of their sons will be affected. Males have only one X chromosome, so they're affected far more often.</p>
<h4>Codominance</h4>
<p>Both alleles are fully expressed together, e.g. red (C<sup>R</sup>C<sup>R</sup>) × white (C<sup>W</sup>C<sup>W</sup>) cattle give roan (C<sup>R</sup>C<sup>W</sup>) offspring with both red and white hairs. AB blood type is another example. Crossing two roans gives 1 red : 2 roan : 1 white.</p>
<div class="tip"><b>Method for every cross</b> (1) Write the key for the alleles. (2) Write the parent genotypes. (3) Write the gametes. (4) Draw the Punnett square. (5) State the genotype and phenotype ratios, then convert to a % or fraction if asked.</div>
<div class="exam"><b>From past papers</b> A homozygous polydactyl cat × a heterozygous cat. A blank Punnett square for colour blindness. Cystic fibrosis (recessive) and Huntington's disorder (dominant) crosses.</div>`,
kw:["homozygous","heterozygous","gene expression","genetic disorder","genotype","phenotype","offspring","monohybrid cross","Punnett square","dominant trait","recessive trait","sex linked inheritance","codominant inheritance","allele"],
cards:[["Bb × Bb phenotype ratio?","3 : 1 (75% dominant, 25% recessive)."],["Bb × bb?","1 Bb : 1 bb, so 50% show each phenotype."],["Why are males more often colour blind?","They only have one X, so a single recessive allele is expressed."],["Codominance example?","Roan cattle (red + white hairs) or AB blood type."]]},

{id:"pedigree", title:"Pedigree charts", group:"Genetics · Inheritance (Booklet 2)",
checks:[
 "Interpret pedigree charts and recognise the pattern of inheritance (autosomal dominant and autosomal recessive).",
 "Investigate X-linked recessive patterns of inheritance."
],
html:`
<p>Squares are males and circles are females. A shaded symbol means affected. A horizontal line joins parents, and a vertical line leads down to their children.</p>
<table><tr><th>Pattern</th><th>Clues</th></tr>
<tr><td><b>Autosomal recessive</b></td><td>Two <b>unaffected</b> parents have an <b>affected</b> child, so both parents must be carriers (Aa). It can skip generations.</td></tr>
<tr><td><b>Autosomal dominant</b></td><td>Two <b>affected</b> parents have an <b>unaffected</b> child, so both parents are Aa. It usually appears in every generation.</td></tr>
<tr><td><b>X-linked recessive</b></td><td>Mostly males are affected. An affected father can't pass it to his sons (he gives them his Y). An affected mother passes it to all of her sons.</td></tr></table>
<div class="tip"><b>Fast check</b> If unaffected parents have an affected child, it's recessive. If affected parents have an unaffected child, it's dominant.</div>
<div class="exam"><b>From past papers</b> Albinism in dogs: two unaffected parents have an albino pup, so it's recessive. Dimples over three generations: two parents with dimples have a child without them, so it's dominant. Night-blindness: X-linked recessive. You also get asked to build a pedigree from a written story.</div>`,
kw:["pedigree chart","autosomal dominant","autosomal recessive","X-linked recessive","carrier"],
cards:[["Unaffected parents, affected child?","Autosomal recessive (both parents are carriers)."],["Affected parents, unaffected child?","Autosomal dominant."],["Can an affected father give an X-linked trait to his son?","No. A son gets his father's Y chromosome."]]},

{id:"species", title:"Species, evolution & variation", group:"Evolution",
checks:[
 "Define the term species as members who can interbreed and produce fertile offspring.",
 "Define evolution.",
 "Revision: identify phenotypic variation within a population (inherited and acquired).",
 "Revision: relate inherited phenotypic differences to differences in DNA (alleles).",
 "Describe how mutations in the DNA can lead to increased variation in a population."
],
html:`
<ul class="notes">
<li><b>Species:</b> a group of organisms that can interbreed and produce <b>fertile</b> offspring. A horse and a donkey make an infertile mule, so they are separate species.</li>
<li><b>Evolution:</b> a change in the inherited characteristics (allele frequencies) of a population over many generations.</li>
<li><b>Variation</b> is the differences between individuals. <b>Inherited variation</b> comes from different alleles. <b>Acquired variation</b> comes from the environment and lifestyle.</li>
<li>Mutations create <b>new alleles</b>, which adds variation to the gene pool. That variation is the raw material for natural selection.</li>
<li><b>Biodiversity</b> is the variety of life: genetic, species and ecosystem diversity.</li>
</ul>`,
kw:["species","evolution","trait","phenotype","acquired variation","inherited variation","population","biodiversity","allele","genotype","mutation","variation"],
cards:[["Define species","Organisms that can interbreed and produce fertile offspring."],["Define evolution","A change in the inherited characteristics of a population over generations."],["Source of new alleles?","Mutation."]]},

{id:"natsel", title:"Natural selection", group:"Evolution",
checks:[
 "Describe the process of natural selection: variation (due to alleles), a change in the environment as a selection pressure, better-suited individuals survive and reproduce, and advantageous alleles and phenotypes become more common (e.g. rock pocket mice, giraffe neck length)."
],
html:`
<div class="flow"><span>1. Variation</span><i>→</i><span>2. Selection pressure</span><i>→</i><span>3. Survival of the best suited</span><i>→</i><span>4. Reproduce, pass on alleles</span><i>→</i><span>5. Allele becomes more common</span></div>
<h4>Worked example: rock pocket mice</h4>
<ol>
<li>Mice vary in coat colour. Dark coats come from a mutation in one gene.</li>
<li>Lava flows create dark rock, and owls hunt by sight. That's the <b>selection pressure</b>.</li>
<li>Dark mice on dark rock are camouflaged, so more of them survive. Light mice get eaten.</li>
<li>The survivors reproduce and pass the dark-coat allele to their offspring.</li>
<li>Over generations, the dark allele and dark phenotype become more common on the lava.</li>
</ol>
<p>The same pattern explains peppered moths (soot-darkened bark), giraffe necks (reaching higher leaves), antibiotic-resistant bacteria and Darwin's finch beaks.</p>
<div class="tip"><b>Avoid this trap</b> Individuals don't change because they "need to". Giraffes didn't stretch their necks. Long-necked giraffes already existed, survived better and passed on their alleles.</div>
<div class="exam"><b>From past papers</b> Trapping data for the mice (dark coats: 89% caught on dark backgrounds). Snail shell colour (pink-brown 58% vs 87% killed). Three panels of bacteria with an antibiotic, peppered moth photos, finch beaks and goldfish varieties.</div>`,
kw:["natural selection","selective pressure","mutation","gene","allele frequency","adaptation"],
cards:[["Selection pressure for rock pocket mice?","Predation by owls against dark lava rock."],["How do bacteria become resistant?","Resistant bacteria already exist. The antibiotic kills the sensitive ones, and the survivors multiply."],["Natural selection in 5 steps?","Variation, selection pressure, survival, reproduction, the allele becomes more common."]]},

{id:"speciation", title:"Allopatric speciation & phylogenetic diagrams", group:"Evolution",
checks:[
 "Understand how allopatric speciation leads to biodiversity.",
 "Draw and interpret a simple phylogenetic diagram."
],
html:`
<div class="flow"><span>One population</span><i>→</i><span>Geographic barrier (river, mountain, isthmus)</span><i>→</i><span>Different selection pressures, mutations and drift on each side</span><i>→</i><span>Can no longer interbreed: 2 species</span></div>
<p>Example: the Isthmus of Panama split a porkfish population into <i>Anisotremus taeniatus</i> (Pacific) and <i>A. virginicus</i> (Caribbean).</p>
<h4>Reading phylogenetic trees</h4>
<ul class="notes">
<li>The tips are species, each node (branch point) is a <b>common ancestor</b>, and the root is the oldest ancestor.</li>
<li>The <b>most closely related</b> species share the <b>most recent</b> common ancestor, meaning the node closest to the tips.</li>
<li>Read the time scale (e.g. mya) to see when two lineages split.</li>
</ul>
<div class="exam"><b>From past papers</b> Swordfish/frog/alligator/T. rex: alligator and T. rex are closest. Primates: chimp and bonobo are closest, and humans are next. Whales and dolphins: the Burrunan and common bottlenose dolphins are sister lineages. Others cover arthropods, P–T trees and Darwin's finches.</div>`,
kw:["speciation","allopatric speciation","isolation","biodiversity","lineage","ancestor","common ancestor","phylogenetic diagram"],
cards:[["What drives allopatric speciation?","A geographic barrier separating populations."],["How do you find the closest relatives on a tree?","Find the most recent shared node."]]}
);
