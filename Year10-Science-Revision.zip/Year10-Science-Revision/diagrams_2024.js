/* ================= 2024 CORE ================= */
dg("core2024","^\\s*18\\. Which sequence forms the complementary", `<div class="dgstrand">DNA strand shown: <b>T – A – G – T – A – A – C – G</b></div>`,
  "The four answer options were in a table image that couldn't be read reliably. Write the complementary strand yourself and check it against the options on your printed paper.");
dg("core2024","^\\s*21\\. The diagrams below represent stages", G.cells([["cyto","A"],["telo","B"],["ana","C"],["meta","D"],["prom","E"],["pro","F"]]),
  "Redrawn from the descriptions of drawings A to F, in the same left-to-right order as the paper.");
dg("core2024","^\\s*31\\. A catalyst", G.graph(H2O2), H2O2note);
dg("core2024","^\\s*Question 1\\b", (()=>{const top="TGACTG", bot="ACTGAC"; let s="";
  s+=`<path d="M30,40 L330,40" stroke-width="5" stroke-opacity=".5"/><path d="M30,140 L330,140" stroke-width="5" stroke-opacity=".5"/>`;
  [...top].forEach((b,i)=>{const x=55+i*52; s+=`<line x1="${x}" y1="44" x2="${x}" y2="88" stroke="#c2551f" stroke-width="5"/><line x1="${x}" y1="92" x2="${x}" y2="136" stroke="#2b5ea8" stroke-width="5"/><line x1="${x-8}" y1="90" x2="${x+8}" y2="90" stroke-dasharray="2 2"/>`+G.T(x,32,b,{b:1,s:15})+G.T(x,160,bot[i],{b:1,s:15});});
  let h=""; for(let k=0;k<=60;k++){const y=10+k*2.8; h+=(k?"L":"M")+(420+30*Math.sin(k/6))+","+y;} let h2=""; for(let k=0;k<=60;k++){const y=10+k*2.8; h2+=(k?"L":"M")+(420-30*Math.sin(k/6))+","+y;}
  s+=`<path d="${h}" stroke-width="2.5"/><path d="${h2}" stroke-width="2.5" stroke-opacity=".6"/>`;
  return G.svg(470,180,s);})(), "Redrawn and simplified: one section of the molecule drawn flat as a ladder (with the triplets TGA, CTG and ACT from the paper's labels), next to the twisted double helix. The paper also shows the molecule coiled around proteins.");
dg("core2024","^\\s*Question 2\\b", G.pedigree({w:640,h:310,names:1,key:"dimples",gen:[{y:40,t:"I"},{y:140,t:"II"},{y:245,t:"III"}],people:[
  {id:"a",x:90,y:40,s:"f",a:1},{id:"b",x:190,y:40,s:"m"},{id:"c",x:410,y:40,s:"f"},{id:"d",x:510,y:40,s:"m",a:1},
  {id:"e",x:60,y:140,s:"m"},{id:"f",x:150,y:140,s:"f"},{id:"g",x:240,y:140,s:"f",a:1},{id:"h",x:410,y:140,s:"m",a:1},{id:"i",x:500,y:140,s:"f"},
  {id:"j",x:325,y:245,s:"f"}],couples:[["a","b"],["c","d"],["g","h"]],kids:[{p:["a","b"],k:["e","f","g"]},{p:["c","d"],k:["h","i"]},{p:["g","h"],k:["j"]}]}),
  "Redrawn from the paper's three-generation pedigree. Shaded means dimples. Type each person's name (and genotype for part d) in the box under their symbol.");
dg("core2024","^\\s*d\\) The diagram, below shows one of the phases", `<div class="dgrow"><div class="dgcell">${G.cell("ana",{w:250,tags:[[150,10,67,10,"1"],[150,46,82,40,"2"],[150,92,73,100,"3"],[150,122,67,120,"4"]]})}</div><div class="dgcell dglist">${[1,2,3,4].map(i=>`<div>${i}. {{IN}}</div>`).join("")}</div></div>`,
  "Redrawn: four arrows (numbered here) pointing to the top spindle pole, the spindle fibres, the separating chromatids and the bottom spindle pole. Label each one.");
dg("core2024","^\\s*Question 8\\b", G.tree({t:28,c:["Old World monkeys",{t:18,c:[{t:6,c:["Siamang","Gibbon"]},{t:14,c:["Orangutan",{t:8,c:["Gorilla",{t:6,c:[{t:2,c:["Bonobo","Chimpanzee"]},"Human"]}]}]}]}]},{w:600,lw:150,rowH:28,time:{max:35,ticks:[35,30,25,20,15,10,5,0],lab:"Millions of years ago"}}),
  "Redrawn: the branching order matches the paper, but the exact branch times couldn't be read, so they're approximate. Check part b) against the time scale on your printed paper.");
dg("core2024","^\\s*Question 12\\b", G.graph({xmax:8,ymax:80,xt:[0,1,2,3,4,5,6,7,8],yt:[0,10,20,30,40,50,60,70,80],xlab:"Time (min)",ylab:"Volume of carbon dioxide (cm³)",
  curves:[{pts:[[0,0],[0.5,22],[1,37],[1.5,44],[2,49],[3,55],[4,60],[5,63],[6,65],[7,65],[8,65]]}]}),
  "Redrawn. Known readings: about 35 to 40 cm³ at 1 min and about 55 cm³ at 3 min, levelling off at about 65 cm³ from about 6 min. In-between values are estimates.");
dg("core2024","^\\s*a\\) The diagram below illustrates three types of thermal", (()=>{let s="";
  s+=`<path d="M140,70 L140,170 Q140,185 155,185 L305,185 Q320,185 320,170 L320,70" stroke-width="3"/><path d="M142,90 L318,90" stroke="#2b5ea8" stroke-opacity=".5"/>`;
  s+=`<path d="M190,170 C170,140 170,115 190,105 M210,105 C230,115 230,140 210,170" stroke="#2b5ea8" stroke-width="2.2"/><path d="M270,170 C250,140 250,115 270,105 M290,105 C310,115 310,140 290,170" stroke="#2b5ea8" stroke-width="2.2"/><path d="M186,110 l4,-6 l3,7 M206,165 l4,6 l3,-7" stroke="#2b5ea8" stroke-width="2"/>`;
  s+=`<path d="M320,110 L430,95" stroke-width="7" stroke-linecap="round" stroke-opacity=".7"/><path d="M420,85 q20,-6 26,10 q4,14 -12,16" stroke-width="2"/>`;
  s+=`<path d="M210,215 q-15,-18 5,-28 q-2,12 10,14 q8,-10 2,-22 q22,14 8,36 Z" fill="#f2a43a" stroke="#c2551f"/>`;
  s+=`<path d="M135,215 q-12,-6 -24,0 t-24,0 M128,240 q-12,-6 -24,0 t-24,0 M300,225 q12,-6 24,0 t24,0" stroke="#c2551f" stroke-width="2"/>`;
  s+=`<foreignObject x="10" y="240" width="130" height="30">{{IN}}</foreignObject><line x1="80" y1="240" x2="100" y2="232" stroke-width="1"/>`;
  s+=`<foreignObject x="330" y="140" width="130" height="30">{{IN}}</foreignObject><line x1="330" y1="150" x2="290" y2="140" stroke-width="1"/>`;
  s+=`<foreignObject x="370" y="40" width="130" height="30">{{IN}}</foreignObject><line x1="400" y1="70" x2="390" y2="100" stroke-width="1"/>`;
  return G.svg(520,280,s);})(), "Redrawn: a pot of water over a flame, with blue current arrows in the water, a metal handle being held, and red wavy lines coming off the flame. Type the type of transfer in each box.");

/* ================= 2024 EXT ================= */
dg("ext2024","^\\s*Question 5\\b", G.cell("telo1"), "Redrawn: a pinched cell with two separated sets of still-duplicated (X-shaped) chromosomes and spindle poles at each end.");
dg("ext2024","^\\s*Question 7\\b", "", "The pedigree for this question couldn't be redrawn reliably. From the descriptions: affected male 1 and unaffected female 2 have children 3 and 9 (unaffected females), 4 (affected male), 6 (unaffected male) and 7 (affected female). Individuals 4 and 5 are both affected, and all their children, 10 to 14, are affected. Use your printed paper for the exact layout.");
