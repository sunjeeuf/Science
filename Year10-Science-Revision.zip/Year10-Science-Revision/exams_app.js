(function(){
const $ = s=>document.querySelector(s);
const esc = s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]));
const SEC = /^\s*(Short Answer|Multiple Choice)\s*$|^\s*(Section [A-Z]\b.*|[A-Z][A-Za-z &]+:\s*(Multiple Choice|Short Answer|Questions).*|(Genetics|Evolution|Biology|Chemistry|Physics|Natural Selection and Evolution|Natural Selection & Evolution|Cellular|Inheritance)\s*:?\s*(Short Answer |Multiple Choice |Short answer |Multiple choice )?(Questions|Section).*)$/;
const QH = /^\s*(Question\s+\d+\b|\d{1,2}\.\s*[A-Za-z“‘"(])/;
const OPT = /^\s*[A-Da-d][\.\)]\s+\S/;
const START = /^\s*(Question\s+1\b|1\.\s+\S)/;
let view = "core", current = null, timerInt = null;

function parse(ex){
  const L = ex.lines;
  const diagrams = {}, toks = [];
  if (L[0].startsWith("A summary of each image")){
    const idx = L.findIndex(l=>l.startsWith("The extracted text of each page"));
    let cur = null;
    L.slice(1, idx).forEach(l=>{
      const m = l.match(/^Page (\d+):\s*(.*)$/);
      if (m){ cur=+m[1]; diagrams[cur]=m[2]; }
      else if (cur && l.trim()) diagrams[cur] += "\n" + l;
    });
    L.slice(idx+1).forEach(l=>{
      const parts = l.split(/Page (\d+) of \d+/);
      parts.forEach((p,i)=>{ if (i%2) toks.push({t:"page",n:+p}); else toks.push({t:"line",s:p}); });
    });
  } else {
    let page = 0, ocr = null;
    L.forEach(l=>{
      const m = l.match(/^=== PAGE (\d+) ===$/);
      if (m){ if (ocr) toks.push(ocr); ocr=null; page=+m[1]; toks.push({t:"page",n:page}); return; }
      if (/^Pages: \d+$/.test(l)) return;
      if (l.trim()==="[EMBEDDED IMAGES TEXT]"){ ocr={t:"ocr",n:page,s:[]}; return; }
      const s = l.replace(/Page \d+ of \d+/g,"");
      if (ocr){ if (s.trim()) ocr.s.push(s); return; }
      toks.push({t:"line",s});
    });
    if (ocr) toks.push(ocr);
  }
  Object.keys(diagrams).forEach(k=>{
    const d = diagrams[k].trim();
    if (+k===1 || /^(No |Blank|\(Blank)/i.test(d)) delete diagrams[k]; else diagrams[k]=d;
  });
  const start = toks.findIndex(t=>t.t==="line" && (START.test(t.s) || SEC.test(t.s)));
  return {diagrams, cover: toks.slice(0, Math.max(start,0)), body: toks.slice(Math.max(start,0))};
}


let parts = [];   // answer parts of the rendered paper: {pid, line, type:'q'|'sub', q}
const qText = {}; // data-q -> question heading line

function lineHTML(s, st){
  let h = esc(s).replace(/_{4,}/g, ()=>{ st.cur.inputs++; return `<input class="blank" data-i="${st.i++}" data-p="${st.pid}">`; });
  return h.replace(/\((\d+\s*marks?)\)/gi,'<span class="mk">($1)</span>');
}

function render(ex){
  const {diagrams, cover, body} = parse(ex);
  const st = {i:0, q:0, ta:[], mc:false, pid:0, cur:{inputs:0, opts:0, type:"none"}};
  parts = [];
  const used = {};
  const D = ((window.DG && DG[ex.id]) || []).map(d=>({...d, seen:0, done:0}));
  const SUB = /^\s*\(?([a-h]|i{1,3}|iv|v)[\)\.]\s/;
  let h = "", pending = [];
  const TA = rows=>{ st.cur.inputs++; return `<textarea rows="${rows}" data-i="${st.i++}" data-p="${st.pid}" placeholder="Your answer…"></textarea>`; };
  const fillIn = s=>s.replace(/\{\{IN\}\}/g, ()=>{ st.cur.inputs++; return `<input class="blank dgin" data-i="${st.i++}" data-p="${st.pid}">`; });
  const fig = d=>`<figure class="dg">${d.h?`<div class="dgart">${fillIn(d.h)}</div>`:""}<figcaption><b>${d.h?"Redrawn diagram":"About the image here"}</b>${esc(d.note)}</figcaption></figure>`;
  const flushP = ()=>{ pending.forEach(d=>h+=fig(d)); pending=[]; };
  const flushTA = ()=>{ if (st.ta.length){ h += TA(Math.min(Math.max(st.ta.length,2),12)); st.ta=[]; } };
  // Close the current part; give it an answer box if the paper left no lines for it.
  const K = (window.KEYS||{})[ex.id];
  const keyed = line=>!!(K && K.sa && K.sa.some(k=>startsQ(line,k[0])));
  const endPart = (nextIsSub)=>{
    const c = st.cur;
    if (c.opts || c.inputs) return;
    const p = parts[parts.length-1];
    if (c.type==="sub" || (c.type==="q" && !nextIsSub && (c.marked || (p && keyed(p.line))))) h += TA(3);
  };
  const desc = (n,txt)=>`<details class="desc"><summary>Written description of the image(s) on page ${n} <small>· may give away answers</small></summary>${esc(txt)}</details>`;
  body.forEach(t=>{
    if (t.t==="page"){ flushTA(); flushP(); h += `<div class="pg">Page ${t.n}</div>`;
      if (diagrams[t.n]){ h += desc(t.n, diagrams[t.n]); used[t.n]=1; } return; }
    if (t.t==="ocr"){ flushTA(); flushP(); if (t.n>1 && t.s.join("").trim().length>3) h += `<details class="desc"><summary>Text read from inside the image(s) on page ${t.n}</summary>${esc(t.s.join("\n"))}</details>`; return; }
    const s = t.s;
    if (!s.trim()){ st.blank=(st.blank||0)+1; if (st.blank===3 && st.q && !st.mc && !st.cur.inputs && !st.cur.opts){ flushP(); h += TA(4); } return; }
    st.blank=0;
    if (/^[\s_.]*$/.test(s) && (s.match(/_/g)||[]).length>=5){ flushP(); st.ta.push(s); return; }
    flushTA();
    const isSec = SEC.test(s) && s.length<90, isQ = !isSec && QH.test(s);
    const isOpt = !isSec && !isQ && (/^\s*[A-D][\.\)]\s+\S/.test(s) || (st.mc && /^\s*[a-d][\.\)]\s+\S/.test(s)));
    const isSub = !isOpt && !isQ && !isSec && SUB.test(s);
    if (isSec||isQ||isOpt||isSub) flushP();
    if (isSec||isQ||isSub){ endPart(isSub); }
    if (isQ||isSub){ st.pid++; st.cur={inputs:0, opts:0, type:isQ?"q":"sub", marked:false}; parts.push({pid:st.pid, line:s.trim(), type:st.cur.type, q:st.q+(isQ?1:0)}); }
    if (isSec){ st.cur={inputs:0, opts:0, type:"none"}; h += `<div class="sec">${esc(s.trim())}</div>`; }
    else if (isQ){ st.q++; qText[st.q]=s.trim(); st.mc = /^\s*\d{1,2}\.\s*\S/.test(s) || /\(1 mark\)/i.test(s); h += `<div class="qh" data-pid="${st.pid}">${lineHTML(s,st)}</div>`; }
    else if (isOpt){ st.cur.opts++; h += `<div class="opt" data-q="${st.q}">${lineHTML(s,st)}</div>`; }
    else h += `<div class="ln"${isSub?` data-pid="${st.pid}"`:""}>${lineHTML(s,st)}</div>`;
    if (/\d\s*marks?\b/i.test(s)) st.cur.marked = true;
    D.forEach(d=>{ if (!d.done && d.m.test(s) && d.seen++===d.n){ d.done=1; pending.push(d); } });
    if (!isQ && pending.length && /[.?:!)]\s*$/.test(s)) flushP();
  });
  flushTA(); flushP(); endPart(false);
  const left = Object.keys(diagrams).filter(k=>!used[k]).sort((a,b)=>a-b);
  const top = left.length ? `<details class="cover"><summary>Written descriptions of this paper's images (${left.length}) · may give away answers</summary>${left.map(k=>`<div class="diag"><b>Page ${k}</b>${esc(diagrams[k])}</div>`).join("")}</details>` : "";
  const coverH = cover.filter(t=>t.t==="line" && t.s.trim()).map(t=>`<div class="ln">${esc(t.s)}</div>`).join("");
  const mins = (ex.lines.join("\n").match(/Writing time:\s*(\d+)/i)||ex.lines.join("\n").match(/Time Allowed:\s*(\d+)/i)||[0, ex.level==="core"?90:30])[1];
  $("#exam").innerHTML = `
    <div class="exam-head"><h2>${ex.title}</h2>
      <span class="timer" id="timer" data-m="${mins}">${mins}:00</span>
      <button id="tstart">▶ Start ${mins}-min timer</button><button id="treset">Reset</button><button id="clear">Clear my answers</button><button id="submit" class="submit">✓ Submit work</button></div>
    <div id="score"></div>
    <div class="ex-note">Questions are copied word for word from your exam. The original pictures couldn't be copied, so graphs, pedigrees, trees, karyotypes and cells have been redrawn from descriptions and placed under their question. Each one says what's approximate. Photos aren't redrawn. Use your printed paper when a note says to.</div>
    ${top}
    <details class="cover"><summary>Cover page & instructions</summary>${coverH}</details>
    <div class="paperbody" id="pb">${h}</div>
    <div class="submitbar"><button class="submit" id="submit2">✓ Submit work</button></div>`;
  restore(ex.id); bindTimer();
  $("#submit").onclick = $("#submit2").onclick = ()=>mark(ex);
}

/* ---------- Marking ---------- */
const startsQ = (line,p)=>{ const l=line.replace(/\s+/g," "), q=p.replace(/\s+/g," "); return l.startsWith(q) && !/^\d/.test(l.slice(q.length)); };
const squash = s=>s.toLowerCase().replace(/[\s^_]/g,"").replace(/[→⟶]/g,"->");
function count(text, alt){
  if (alt.startsWith("~")){ const a=alt.slice(1).replace(/[\s^_]/g,""), t=text.replace(/[\s^_]/g,""); return t.split(a).length-1; }
  if (alt.startsWith("w:")){ const r=new RegExp("(^|[^a-z0-9])"+alt.slice(2).replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(?![a-z0-9])","gi"); return (text.match(r)||[]).length; }
  if (alt.startsWith("=")) return text.trim().toLowerCase()===alt.slice(1).toLowerCase() ? 1 : 0;
  if (alt.startsWith("r:")) return (text.match(new RegExp(alt.slice(2),"gi"))||[]).length;
  const a=squash(alt); return a ? squash(text).split(a).length-1 : 0;
}
function scoreSA(text, groups, marks){
  const need={}; let hit=0; const res=[];
  groups.forEach(g=>{ need[g]=(need[g]||0)+1; const n=Math.max(...g.split("|").map(a=>count(text,a))); const ok=n>=need[g]; if(ok) hit++; res.push(ok); });
  return {got: Math.round(marks*hit/groups.length*2)/2, res};
}
const letterOf = el=>{ const m=el.textContent.trim().match(/^\(?([A-Da-d])[\.\)]/); return m?m[1].toUpperCase():null; };

function mark(ex){
  document.querySelectorAll("#pb .fb").forEach(e=>e.remove());
  document.querySelectorAll("#pb .opt").forEach(e=>e.classList.remove("right","wrong","missed"));
  const K = (window.KEYS||{})[ex.id];
  if (!K){ $("#score").innerHTML = `<div class="scorecard"><b>No answer key for this paper yet.</b></div>`; return; }
  // Multiple choice
  const mc = {}; (K.mc||"").trim().split(/\s+/).forEach(t=>{ const m=t.match(/^(\d+)([A-D?])$/); if(m) mc[m[1]]=m[2]; });
  let mcGot=0, mcTot=0, mcSkip=0; const groups={};
  document.querySelectorAll("#pb .opt").forEach(o=>(groups[o.dataset.q]=groups[o.dataset.q]||[]).push(o));
  Object.entries(groups).forEach(([q,opts])=>{
    const n = ((qText[q]||"").match(/^(?:Question\s+)?(\d+)/)||[])[1]; const ans = mc[n];
    const last = opts[opts.length-1];
    if (!ans || ans==="?"){ mcSkip++; last.insertAdjacentHTML("afterend",`<div class="fb fb-skip">Not auto-marked: the options for this question came from an image I couldn't read. Check it against your printed paper.</div>`); return; }
    mcTot++;
    const pick = opts.find(o=>o.classList.contains("pick")), right = opts.find(o=>letterOf(o)===ans);
    if (right) right.classList.add(pick===right?"right":"missed");
    if (pick && pick!==right) pick.classList.add("wrong");
    if (pick===right && pick) mcGot++;
    last.insertAdjacentHTML("afterend",`<div class="fb ${pick===right&&pick?"fb-ok":"fb-no"}">${pick===right&&pick?"✓ Correct":pick?"✗ Answer: "+ans:"Not answered · Answer: "+ans}${K.why&&K.why[n]?` · ${esc(K.why[n])}`:""}</div>`);
  });
  // Short answer
  let saGot=0, saTot=0, selfTot=0;
  const seen={};
  (K.sa||[]).forEach(([prefix, marks, kw, model, nth=0])=>{
    const matches = parts.filter(p=>startsQ(p.line, prefix));
    const p = matches[nth]; if (!p) return;
    const els = [...document.querySelectorAll(`#pb [data-p="${p.pid}"]`)];
    const text = els.map(e=>e.value||"").join(" \n ");
    const anchor = els.length ? (els[els.length-1].closest("figure.dg")||els[els.length-1].closest(".ln,.qh")||els[els.length-1]) : document.querySelector(`#pb [data-pid="${p.pid}"]`);
    if (!anchor) return;
    let fb;
    if (!kw){ selfTot+=marks; fb=`<div class="fb fb-self"><b>Mark this one yourself (${marks} mark${marks>1?"s":""})</b><div class="model">Suggested answer: ${esc(model)}</div></div>`; }
    else {
      const groups = kw.split(";").map(g=>g.trim()).filter(Boolean);
      const {got, res} = text.trim() ? scoreSA(text, groups, marks) : {got:0,res:groups.map(()=>false)};
      saGot+=got; saTot+=marks;
      const cls = got>=marks?"fb-ok":got>0?"fb-part":"fb-no";
      fb=`<div class="fb ${cls}"><b>${got} / ${marks}</b> <span class="est">estimated from key words</span>${!text.trim()?" · not answered":""}<div class="model">Suggested answer: ${esc(model)}</div><div class="kws">Key ideas: ${groups.map((g,i)=>`<span class="${res[i]?"y":"n"}">${esc(g.split("|")[0].replace(/^(~|w:|=|r:)/,""))}</span>`).join("")}</div></div>`;
    }
    anchor.insertAdjacentHTML("afterend", fb);
  });
  const tot = mcGot+saGot, max = mcTot+saTot;
  $("#score").innerHTML = `<div class="scorecard">
    <div class="big">${tot} <small>/ ${max}</small></div>
    <div class="sc-rows"><div><b>Multiple choice:</b> ${mcGot} / ${mcTot}${mcSkip?` <span class="muted">(${mcSkip} not auto-marked)</span>`:""}</div>
    <div><b>Short answer:</b> ${saGot} / ${saTot} <span class="muted">estimated from key words</span></div>
    ${selfTot?`<div><b>Mark yourself:</b> ${selfTot} more marks (drawings, tables and graphs) <span class="muted">not counted above</span></div>`:""}</div>
    <div class="sc-note">Multiple choice is marked exactly. Short answers are scored by looking for the key ideas a marker would expect, so read each suggested answer and adjust your mark if you said it in different words. These answers were written for this site, not taken from an official marking guide.</div></div>`;
  $("#score").scrollIntoView({behavior:"smooth", block:"start"});
}

function store(id){ return JSON.parse(localStorage.getItem("cgs-ex3-"+id)||'{"f":{},"o":{}}'); }
function save(id,d){ localStorage.setItem("cgs-ex3-"+id, JSON.stringify(d)); cards(); }
function restore(id){
  const d = store(id);
  document.querySelectorAll("#pb [data-i]").forEach(el=>{ if (d.f[el.dataset.i]) el.value=d.f[el.dataset.i]; });
  document.querySelectorAll("#pb .opt").forEach((el,i)=>{ if (d.o[el.dataset.q]===i) el.classList.add("pick"); });
}
document.addEventListener("input",e=>{
  if (!current || !e.target.closest("#pb") || e.target.dataset.i===undefined) return;
  const d=store(current.id); d.f[e.target.dataset.i]=e.target.value; save(current.id,d);
});
document.addEventListener("click",e=>{
  const o=e.target.closest("#pb .opt"); if (!o||!current) return;
  const all=[...document.querySelectorAll("#pb .opt")], i=all.indexOf(o), d=store(current.id);
  const was=o.classList.contains("pick");
  all.filter(x=>x.dataset.q===o.dataset.q).forEach(x=>x.classList.remove("pick"));
  if (was) delete d.o[o.dataset.q]; else { o.classList.add("pick"); d.o[o.dataset.q]=i; }
  save(current.id,d);
});

function bindTimer(){
  clearInterval(timerInt); timerInt=null;
  const el=$("#timer"), m=+el.dataset.m; let left=m*60;
  const show=()=>{ el.textContent=`${Math.floor(left/60)}:${String(left%60).padStart(2,"0")}`; el.classList.toggle("low",left<300); };
  $("#tstart").onclick=e=>{
    if (timerInt){ clearInterval(timerInt); timerInt=null; e.target.textContent="▶ Resume"; return; }
    e.target.textContent="❚❚ Pause";
    timerInt=setInterval(()=>{ if(left>0){left--;show();} else {clearInterval(timerInt);timerInt=null;el.textContent="Time's up";} },1000);
  };
  $("#treset").onclick=()=>{ clearInterval(timerInt); timerInt=null; left=m*60; show(); $("#tstart").textContent=`▶ Start ${m}-min timer`; };
  $("#clear").onclick=()=>{ if (confirm("Clear all your answers for this paper?")){ localStorage.removeItem("cgs-ex3-"+current.id); render(current); cards(); } };
}

function cards(){
  const list = EXAMS.filter(x=>x.level===view).sort((a,b)=>b.year-a.year);
  $("#papers").innerHTML = list.map(x=>{
    const d=store(x.id), n=Object.values(d.f).filter(v=>v&&v.trim()).length+Object.keys(d.o).length;
    const txt=x.lines.join("\n"), w=(txt.match(/Writing time:\s*(\d+)/i)||txt.match(/Time Allowed:\s*(\d+)/i)||[0,"?"])[1];
    return `<button class="paper ${x.level} ${current&&current.id===x.id?"on":""}" data-id="${x.id}"><div class="yr">${x.year}</div><div class="meta">${x.level==="core"?"Core":"Extension"} · ${w} min writing</div><div class="prog">${n?n+" answers saved":"Not started"}</div></button>`;
  }).join("");
}
$("#papers").addEventListener("click",e=>{
  const b=e.target.closest(".paper"); if(!b) return;
  current=EXAMS.find(x=>x.id===b.dataset.id); render(current); cards();
  $("#exam").scrollIntoView({behavior:"smooth"});
});
document.querySelector("nav.tabs").addEventListener("click",e=>{
  const b=e.target.closest("button[data-v]"); if(!b) return;
  document.querySelectorAll("nav.tabs button[data-v]").forEach(x=>x.classList.toggle("on",x===b));
  view=b.dataset.v; current=EXAMS.filter(x=>x.level===view).sort((a,b)=>b.year-a.year)[0]; render(current); cards();
});

const themeBtn=$("#theme");
const lab=()=>{};
themeBtn.onclick=()=>{const t=document.documentElement.dataset.theme==="dark"?"light":"dark";document.documentElement.dataset.theme=t;localStorage.setItem("cgs-sem2-theme",t);lab();};
lab();

const want = EXAMS.find(x=>x.id===location.hash.slice(1));
if (want){ view=want.level; document.querySelectorAll("nav.tabs button[data-v]").forEach(x=>x.classList.toggle("on",x.dataset.v===view)); }
current = want || EXAMS.filter(x=>x.level==="core").sort((a,b)=>b.year-a.year)[0];
render(current); cards();
})();
