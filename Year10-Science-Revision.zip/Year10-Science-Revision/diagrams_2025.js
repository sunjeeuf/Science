// Redrawn diagrams, attached after the matching question heading.
// m: regex for the question heading; n: which occurrence (0 = first); h: html; note: caveat shown under it.
window.DG = {};
const dg = (ex, m, h, note, n=0) => (DG[ex] = DG[ex] || []).push({m:new RegExp(m), n, h, note});
const arc = (cx,cy,r,a0,a1)=>{const p=a=>[cx+r*Math.cos((a-90)*Math.PI/180), cy+r*Math.sin((a-90)*Math.PI/180)];const [x0,y0]=p(a0),[x1,y1]=p(a1);return `M${cx},${cy} L${x0},${y0} A${r},${r} 0 ${a1-a0>180?1:0} 1 ${x1},${y1} Z`;};
const lab = (cx,cy,r,a,t)=>{const x=cx+r*Math.cos((a-90)*Math.PI/180), y=cy+r*Math.sin((a-90)*Math.PI/180);return G.T(x,y+5,t,{b:1,s:16});};
const H2O2 = {xmax:40,ymax:70,xt:[0,5,10,15,20,25,30,35,40],yt:[0,10,20,30,40,50,60,70],xlab:"Time (s)",ylab:"Volume of gas produced (cm³)",
  curves:[{pts:[[0,0],[5,25],[10,40],[15,50],[20,56],[25,59],[30,60],[35,60],[40,60]]}]};
const H2O2note = "Redrawn. Only these readings are known: about 50 cm³ at 15 s, levelling off at about 60 cm³ from about 30 s. The rest of the curve's shape is estimated, so check the original before working out a rate.";

/* ================= 2025 CORE ================= */
dg("core2025","^\\s*Question 1\\b", G.svg(300,240,
  `<path d="${arc(150,120,100,0,150)}" fill="var(--phys-l)"/><path d="${arc(150,120,100,150,250)}" fill="var(--bio-l)"/><path d="${arc(150,120,100,250,305)}" fill="var(--chem-l)"/>`+
  [305,319,333,347].map((a,i)=>`<path d="${arc(150,120,100,a,a+14)}" fill="var(--ext-l)"/>`).join("")+
  lab(150,120,60,75,"A")+lab(150,120,60,200,"B")+lab(150,120,60,277,"C")+
  `<path d="M${150+112*Math.cos((300-90)*Math.PI/180)},${120+112*Math.sin((300-90)*Math.PI/180)} A112,112 0 0 1 150,8" stroke-width="2"/>`+G.T(70,30,"D",{b:1,s:16})+
  `<circle cx="150" cy="120" r="100"/>`),
  "Redrawn: three large regions A, B and C, plus a smaller section D split into stages. Sizes are approximate.");
dg("core2025","^\\s*d\\) Fill in the gaps", `<div class="dgrow">${[
   ["inter","",{tags:[[150,24,100,30,"Y"]]}],["pro",""],["meta","",{tags:[[150,80,85,52,"X"]]}],["ana",""],["telo",""]]
   .map(([s,l,o])=>`<div class="dgcell">${G.cell(s,o||{})}<div class="dglab">{{IN}}</div></div>`).join("")}</div>`,
  "Redrawn: cells going round the cycle in order, with a box under each for the stage name. Y points to the centriole pair and X to the spindle.");
dg("core2025","^\\s*Question 3\\b", G.karyo({sex:"XY",tri:8}), "Redrawn: chromosome pairs 1 to 22 plus X and Y, with three copies of chromosome 8.");
dg("core2025","^\\s*c\\) Two parents, who are carriers", G.punnett(), "Type the alleles into the headers and cells.");
dg("core2025","^\\s*a\\) Complete the Punnett square below to show the outcome when a heterozygous black", G.punnett(), "Type the alleles into the headers and cells.");
dg("core2025","^\\s*Question 7\\b", G.pedigree({w:420,h:175,key:"albino",people:[{id:1,x:110,y:40,s:"f",n:1},{id:2,x:210,y:40,s:"m",n:2},{id:3,x:120,y:125,s:"f",a:1,n:3},{id:4,x:200,y:125,s:"m",n:4}],couples:[[1,2]],kids:[{p:[1,2],k:[3,4]}]}), "Redrawn from the paper's pedigree.");
dg("core2025","^\\s*Question 8\\b", G.pedigree({w:620,h:275,people:[
  {id:1,x:80,y:40,s:"m",a:1,n:1},{id:2,x:170,y:40,s:"f",a:1,n:2},{id:3,x:400,y:40,s:"f",n:3},{id:4,x:490,y:40,s:"m",a:1,n:4},
  {id:5,x:60,y:135,s:"u",a:1,n:5},{id:6,x:130,y:135,s:"u",a:1,n:6},{id:7,x:200,y:135,s:"m",n:7},{id:8,x:400,y:135,s:"f",n:8},{id:9,x:480,y:135,s:"m",a:1,n:9},
  {id:10,x:250,y:230,s:"u",n:10},{id:11,x:300,y:230,s:"u",n:11},{id:12,x:350,y:230,s:"u",n:12}],
  couples:[[1,2],[3,4],[7,8]],kids:[{p:[1,2],k:[5,6,7]},{p:[3,4],k:[8,9]},{p:[7,8],k:[10,11,12]}]}),
  "Redrawn from the paper's pedigree. Who is affected matches the original. Diamonds mean the person's sex wasn't clear from the description.");
dg("core2025","^\\s*Question 9\\b", (()=>{
  const bac=(x,y,k)=>k==="g"?`<ellipse cx="${x}" cy="${y}" rx="11" ry="7" fill="#9a9a9a"/>`:k==="w"?`<ellipse cx="${x}" cy="${y}" rx="11" ry="7" fill="var(--card)"/>`:`<ellipse cx="${x}" cy="${y}" rx="11" ry="7" fill="currentColor"/>`;
  const dots=(x0)=>[...Array(14)].map((_,i)=>`<circle cx="${x0+12+(i*37)%150}" cy="${20+(i*53)%120}" r="2.4" fill="#9a9a9a" stroke="none"/>`).join("");
  const P=[[...Array(11)].map(()=>"g").concat(["w"]),["d","d","d","d","d","g","g","g","w","w"],["w","w","w","w","w","w","w","w","d","d","d"]];
  let s=""; P.forEach((p,i)=>{const x0=10+i*200; s+=`<rect x="${x0}" y="8" width="170" height="140" rx="6"/>`+(i?dots(x0):"")+p.map((k,j)=>bac(x0+28+(j%4)*38,32+Math.floor(j/4)*40,k)).join("")+G.T(x0+85,166,"Panel "+(i+1),{b:1}); if(i<2) s+=`<path d="M${x0+176},78 l18,0 m-6,-6 l6,6 l-6,6"/>`;});
  s+=`<ellipse cx="30" cy="192" rx="11" ry="7" fill="#9a9a9a"/>`+G.T(46,196,"antibiotic-sensitive",{a:"start",s:11.5})+`<ellipse cx="200" cy="192" rx="11" ry="7" fill="var(--card)"/>`+G.T(216,196,"antibiotic-resistant",{a:"start",s:11.5})+`<ellipse cx="370" cy="192" rx="11" ry="7" fill="currentColor"/>`+G.T(386,196,"dead",{a:"start",s:11.5})+`<circle cx="450" cy="192" r="3" fill="#9a9a9a" stroke="none"/>`+G.T(460,196,"antibiotic",{a:"start",s:11.5});
  return G.svg(590,210,s); })(), "Redrawn: the population before the antibiotic, during treatment, and after. Bacterium counts are approximate.");
dg("core2025","^\\s*Question 10\\b", G.tree({c:[{c:["A","B"]},{c:["C","D"]}]},{w:360,lw:60,rowH:34}), "Redrawn from the paper's tree.");
dg("core2025","^\\s*Question 11\\b", G.tree({c:["Certhidea olivacea",{c:["Certhidea fusca",{c:["Pinaroloxias inornata",{c:["Platyspiza crassirostris",{c:[{c:["Camarhynchus pallida",{c:["Camarhynchus pauper","Camarhynchus psittacula","Camarhynchus parvulus"]}]},{c:["Geospiza difficilis",{c:[{c:["Geospiza scandens","Geospiza conirostris"]},{c:["Geospiza magnirostris","Geospiza fortis","Geospiza fuliginosa"]}]}]}]}]}]}]}]},{w:600,lw:200,rowH:24,italic:1}),
  "Redrawn: the description only says that G. scandens groups most closely with G. conirostris and that Certhidea olivacea sits on the deepest branch. The other branches follow the usual published tree, which may differ from your paper.");
dg("core2025","^\\s*Question 13\\b", G.graph({xmax:10,ymax:10,noscale:1,xlab:"Time",ylab:"Concentration",curves:[{f:x=>9.2*Math.exp(-x/1.8)+0.3,color:"#2b5ea8",label:"Reagents",lx:0.4,ly:9.6},{f:x=>9.2*(1-Math.exp(-x/1.8)),color:"#c2551f",label:"Products",lx:6,ly:8.6}]}),
  "Redrawn: the reagents fall and the products rise, then both level off. There's no scale on the original.");
dg("core2025","^\\s*a\\) For each of the following examples, identify whether the heat", G.table(["Example","Conduction","Convection","Radiation"],
  ["A metal spoon getting hot in a cup of tea","Warm air rising above a heater","The Sun warming your face","Feeling warmth from a campfire without touching it","Boiling water circulating in a kettle","Heating a metal rod at one end and feeling the other end get hot"].map(e=>[e,"{{IN}}","{{IN}}","{{IN}}"])),
  "This table is printed at the very end of the paper. It's repeated here so you can put an x in the right column.");
dg("core2025","^\\s*12\\. Which of the following matches the terms gene and allele", "", "The answer options for this question were in a table image that couldn't be read. Use your printed paper for the options.");

/* ================= 2025 EXT ================= */
dg("ext2025","^\\s*Question 7\\b", G.punnett(), "Type the alleles into the headers and cells.");
dg("ext2025","^\\s*Question 10\\b", G.graph({xmax:10,ymax:10,noscale:1,xlab:"Time (s)",ylab:"Mass of silver chloride produced",
  curves:[{f:x=>8.6*(1-Math.exp(-x/1.9)),color:"#2b5ea8",label:"X",lx:9.3,ly:9.1},{f:x=>4.6*(1-Math.exp(-x/2.6)),color:"#c2551f",label:"Y",lx:9.3,ly:5.1}],
  lab:[{x:0.55,y:3.6,t:"A",a:"end"},{x:2.5,y:6.4,t:"B",a:"end"},{x:7,y:9.3,t:"C"}]}),
  "Redrawn: curve X rises faster and levels off higher than Y. A marks the start of X, B the middle and C the flat end. There's no scale on the original.");
dg("core2025","^\\s*Refer to the phylogenetic tree below to answer questions 22", (()=>{
  const L=G.L, T=G.T; let s="";
  const leaf={P:[70,40],Q:[140,40],R:[230,40],S:[300,40],T:[430,40]};
  const n1=[265,95], n2=[105,105], n3=[185,160], n4=[310,225];
  s+=L(70,48,n2[0],n2[1])+L(140,48,n2[0],n2[1])+L(230,48,n1[0],n1[1])+L(300,48,n1[0],n1[1]);
  s+=L(n2[0],n2[1],n3[0],n3[1])+L(n1[0],n1[1],n3[0],n3[1])+L(n3[0],n3[1],n4[0],n4[1])+L(430,48,n4[0],n4[1])+L(n4[0],n4[1],n4[0],262);
  Object.entries(leaf).forEach(([k,[x,y]])=>s+=T(x,y-6,k,{b:1,s:15}));
  [[n1,1],[n2,2],[n3,3],[n4,4],[[397,124],5]].forEach(([p,k])=>s+=`<circle cx="${p[0]}" cy="${p[1]}" r="10" fill="var(--card)"/>`+T(p[0],p[1]+4,k,{b:1,s:11}));
  s+=`<path d="M490,250 L490,30 m-6,10 l6,-10 l6,10"/>`+T(490,20,"Present",{s:11.5})+T(505,150,"Time",{s:11.5,r:90});
  return G.svg(520,280,s); })(),
  "Redrawn: time runs upward to the present. R and S join at 1, P and Q at 2, those two groups at 3, and everything with T at 4. Point 5 is on the branch leading to T. Positions are approximate.");
