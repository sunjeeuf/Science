DATA.ext.bio.push(
{id:"drift", title:"Genetic drift: founder & bottleneck effects", group:"Evolution", src:"Marked EXT on checklist",
checks:[
 "EXT: Describe the term genetic drift and explain how it can lead to evolution."
],
html:`
<ul class="notes">
<li><b>Gene pool:</b> all the alleles in a population. <b>Allele frequency:</b> how common one allele is in that gene pool.</li>
<li><b>Genetic drift:</b> a <b>random</b> change in allele frequency from one generation to the next, caused by chance rather than by fitness. It has the strongest effect in <b>small populations</b>.</li>
<li><b>Founder effect:</b> a small group leaves and starts a new population. Its alleles are a random, unrepresentative sample of the original population, so some alleles end up rare and others common.</li>
<li><b>Bottleneck effect:</b> a disaster (fire, flood, hunting) suddenly shrinks a population. The survivors carry only a random fraction of the original alleles, which reduces genetic diversity.</li>
<li><b>How this leads to evolution:</b> allele frequencies change over generations, and some alleles can be lost or become "fixed" (the only version left). That change in allele frequency is evolution.</li>
</ul>
<div class="tip"><b>Drift vs selection</b> Natural selection is <i>non-random</i>: the best-suited survive. Drift is <i>random</i>: the lucky survive.</div>
<div class="exam"><b>From past papers</b> A table shows 100 white + 100 grey mice split into Population A (38 white, 49 grey) and Population B (62 white, 51 grey). The proportions changed by chance at separation, so this is genetic drift / founder effect. Grevy's zebra introduced to Tsavo is a founder population.</div>`,
kw:["genetic drift","founder effect","bottleneck effect","population bottleneck","gene pool","allele frequency"],
ekw:true,
cards:[["Define genetic drift","A random change in allele frequency, strongest in small populations."],["Founder vs bottleneck?","Founder: a small group starts a new population. Bottleneck: a disaster shrinks an existing one."],["Why does drift count as evolution?","Allele frequencies in the population change over generations."]]},

{id:"flow", title:"Gene flow", group:"Evolution", src:"Marked EXT on checklist",
checks:[
 "EXT: Describe the term gene flow and explain how it can lead to evolution (migration and interbreeding moving alleles into a population)."
],
html:`
<ul class="notes">
<li><b>Gene flow:</b> alleles move between populations when individuals <b>migrate</b> and <b>interbreed</b>. Pollen blown to another area counts too.</li>
<li>It brings <b>new alleles</b> into a gene pool or changes how common existing ones are, so allele frequencies change. That's evolution.</li>
<li>Gene flow makes populations <b>more similar</b> to each other. When a barrier <b>stops</b> gene flow, populations drift apart and can become new species (this links back to allopatric speciation).</li>
</ul>
<div class="exam"><b>From past papers</b> Grevy's zebra: if the introduced Tsavo population met the wild populations and interbred, alleles would flow between them.</div>`,
kw:["gene flow","genetic flow","migration","interbreeding","gene pool"],
ekw:true,
cards:[["Define gene flow","Alleles moving between populations through migration and interbreeding."],["Effect of gene flow on two populations?","It makes them more genetically similar."],["What happens when gene flow stops?","The populations diverge, which can lead to speciation."]]},

{id:"anti", title:"DNA in more depth: antiparallel strands", group:"Genetics", src:"Likely bold keyword",
checks:[
 "Describe the two DNA strands as antiparallel."
],
html:`
<ul class="notes">
<li>The two strands of DNA run in <b>opposite directions</b>: one runs 5'→3' and the other 3'→5'. That's what <b>antiparallel</b> means.</li>
<li>The sugar-phosphate backbone has a direction, so the complementary strand always sits "upside-down" relative to the first.</li>
<li>Because of this, A–T and G–C pairs fit together evenly, giving the helix a constant width.</li>
</ul>`,
kw:["antiparallel","deoxyribose sugar","complementary strand"], ekw:true,
cards:[["What does antiparallel mean?","The two DNA strands run in opposite directions (5'→3' and 3'→5')."]]}
);
