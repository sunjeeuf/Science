window.DATA = {core:{bio:[],chem:[],phys:[]}, ext:{bio:[],chem:[],phys:[]}};

// Cell-division drawing helpers: X = duplicated chromosome, V = single chromatid moving to a pole (d=1 left, -1 right), C = centriole pair
const MIT = (()=>{
  const O="#e8692c", P="#8a6fe8";
  const X=(x,y,c,r=0,s=1)=>`<g transform="translate(${x} ${y}) rotate(${r}) scale(${s})"><path d="M-5 -13 Q0 0 -5 13 M5 -13 Q0 0 5 13" stroke="${c}" stroke-width="4.5" stroke-linecap="round" fill="none"/><circle r="2.6" fill="currentColor"/></g>`;
  const V=(x,y,c,d,s=1)=>`<g transform="translate(${x} ${y}) scale(${d*s} ${s})"><path d="M9 -13 Q-1 0 9 13" stroke="${c}" stroke-width="4.5" stroke-linecap="round" fill="none"/><circle cx="4" r="2.3" fill="currentColor"/></g>`;
  const C=(x,y,r=0)=>`<g transform="translate(${x} ${y}) rotate(${r})" fill="rgba(70,180,110,.55)" stroke="currentColor" stroke-width="1"><rect x="-6" y="-2.5" width="9" height="5" rx="1"/><rect x="1" y="-6" width="5" height="9" rx="1"/></g>`;
  const fib=(x,y,pts)=>pts.map(([a,b])=>`<line x1="${x}" y1="${y}" x2="${a}" y2="${b}"/>`).join("");
  const mem=`fill="rgba(232,105,44,.07)" stroke="currentColor" stroke-width="1.8"`, nuc=`fill="rgba(130,110,230,.15)" stroke="currentColor" stroke-width="1.5"`;
  const sp=`stroke="currentColor" stroke-width=".9" opacity=".45"`;
  const chromatin=(x,y)=>`<path d="M${x-16} ${y-6} q5 -7 10 0 t10 0 t10 -2" stroke="${O}" stroke-width="1.4" fill="none"/><path d="M${x-14} ${y+7} q6 6 12 0 t12 1" stroke="${P}" stroke-width="1.4" fill="none"/>`;
  const panel=(name,body,note)=>`<div class="mstage"><svg viewBox="0 0 160 160" role="img" aria-label="${name}"><g transform="rotate(90 80 80)">${body}</g></svg><div class="dglab">${name}</div><div class="mnote">${note}</div></div>`;
  const ys=[50,68,92,110], cs=[O,O,P,P], ss=[1,.75,1,.75];
  const stages = [
    panel("Interphase",`<ellipse cx="80" cy="80" rx="66" ry="58" ${mem}/><circle cx="80" cy="84" r="30" ${nuc}/><circle cx="90" cy="76" r="7" fill="rgba(130,110,230,.5)"/>${chromatin(76,88)}${C(80,38)}`,"DNA copied, chromosomes not yet visible"),
    panel("Prophase",`<ellipse cx="80" cy="80" rx="66" ry="58" ${mem}/><circle cx="80" cy="84" r="34" fill="rgba(130,110,230,.08)" stroke="currentColor" stroke-width="1.4" stroke-dasharray="6 5"/><g ${sp}>${fib(30,64,[[56,70],[58,100],[48,58]])}${fib(130,96,[[104,100],[102,72],[112,104]])}</g>${X(66,72,O)}${X(98,74,O,15,.75)}${X(70,102,P,30)}${X(98,100,P,-20,.75)}${C(30,64)}${C(130,96)}`,"X-shaped chromosomes, nuclear membrane breaks down"),
    panel("Metaphase",`<ellipse cx="80" cy="80" rx="66" ry="58" ${mem}/><line x1="80" y1="26" x2="80" y2="134" stroke="currentColor" stroke-dasharray="3 4" opacity=".5"/><g ${sp}>${fib(22,80,ys.map(y=>[80,y]))}${fib(138,80,ys.map(y=>[80,y]))}</g>${ys.map((y,i)=>X(80,y,cs[i],0,ss[i])).join("")}${C(22,80)}${C(138,80)}`,"Chromosomes line up on the equator"),
    panel("Anaphase",`<ellipse cx="80" cy="80" rx="70" ry="54" ${mem}/><g ${sp}>${fib(18,80,ys.map(y=>[47,y]))}${fib(142,80,ys.map(y=>[113,y]))}</g>${ys.map((y,i)=>V(46,y,cs[i],1,ss[i])+V(114,y,cs[i],-1,ss[i])).join("")}${C(18,80)}${C(142,80)}`,"Sister chromatids pulled to opposite poles"),
    panel("Telophase",`<path d="M80 34 C120 18 152 45 152 80 C152 115 120 142 80 126 C40 142 8 115 8 80 C8 45 40 18 80 34 Z" ${mem}/><circle cx="46" cy="84" r="21" ${nuc}/><circle cx="114" cy="84" r="21" ${nuc}/>${chromatin(48,85)}${chromatin(116,85)}${C(46,50)}${C(114,50)}`,"Two new nuclei form, cell starts to pinch"),
    panel("Cytokinesis",`<ellipse cx="42" cy="82" rx="36" ry="46" ${mem}/><ellipse cx="118" cy="82" rx="36" ry="46" ${mem}/><circle cx="42" cy="88" r="17" ${nuc}/><circle cx="118" cy="88" r="17" ${nuc}/>${chromatin(44,89)}${chromatin(120,89)}${C(42,52)}${C(118,52)}`,"Cytoplasm splits: 2 identical daughter cells")
  ].join("");

  const L=[170,210,250,290], big=`<svg viewBox="0 0 460 260" font-family="system-ui,sans-serif" font-size="12.5" fill="currentColor" role="img" aria-label="Labelled metaphase cell">
<ellipse cx="230" cy="130" rx="95" ry="112" ${mem}/><line x1="125" y1="130" x2="335" y2="130" stroke="currentColor" stroke-dasharray="4 5" opacity=".5"/>
<g ${sp} stroke-width="1.1">${fib(230,36,L.map(x=>[x,130]))}${fib(230,224,L.map(x=>[x,130]))}</g>
${L.map((x,i)=>X(x,130,cs[i],90,1.6*ss[i])).join("")}${C(230,36)}${C(230,224)}
<g stroke="currentColor" stroke-width="1" opacity=".6"><line x1="68" y1="36" x2="220" y2="36"/><line x1="88" y1="84" x2="199" y2="84"/><line x1="96" y1="196" x2="153" y2="196"/><line x1="380" y1="56" x2="256" y2="119"/><line x1="380" y1="98" x2="292" y2="128"/><line x1="398" y1="134" x2="337" y2="130"/><line x1="356" y1="172" x2="298" y2="137"/></g>
<text x="8" y="40">Centriole</text><text x="8" y="88">Spindle fibre</text><text x="8" y="200">Cell membrane</text>
<text x="452" y="60" text-anchor="end">Chromosome</text><text x="452" y="102" text-anchor="end">Centromere</text><text x="452" y="138" text-anchor="end">Equator</text><text x="452" y="176" text-anchor="end">Sister chromatid</text></svg>`;

  const seg=(d,f,t,x,y)=>`<path d="${d}" fill="${f}" stroke="currentColor" stroke-width="1.5"/><text x="${x}" y="${y}" text-anchor="middle" font-weight="700" font-size="15">${t}</text>`;
  const leg=(y,f,t,a,b)=>`<rect x="300" y="${y-11}" width="13" height="13" rx="3" fill="${f}" stroke="currentColor" stroke-width="1"/><text x="322" y="${y}"><tspan font-weight="700">${t}</tspan> ${a}</text><text x="322" y="${y+16}" fill-opacity=".75">${b}</text>`;
  const F=["rgba(232,105,44,.38)","rgba(130,110,230,.42)","rgba(80,150,230,.38)","rgba(70,180,110,.5)","rgba(229,72,77,.42)"];
  const cyc=`<svg viewBox="0 0 560 300" font-family="system-ui,sans-serif" font-size="12.5" fill="currentColor" role="img" aria-label="Cell cycle diagram">
${seg("M150 40 A110 110 0 0 1 234.3 220.7 L197.5 189.9 A62 62 0 0 0 150 88 Z",F[0],"G1",228,118)}
${seg("M234.3 220.7 A110 110 0 0 1 65.7 220.7 L102.5 189.9 A62 62 0 0 0 197.5 189.9 Z",F[1],"S",150,241)}
${seg("M65.7 220.7 A110 110 0 0 1 50.3 103.5 L93.8 123.8 A62 62 0 0 0 102.5 189.9 Z",F[2],"G2",65,166)}
${seg("M50.3 103.5 A110 110 0 0 1 112.4 46.6 L128.8 91.7 A62 62 0 0 0 93.8 123.8 Z",F[3],"M",92,92)}
${seg("M112.4 46.6 A110 110 0 0 1 150 40 L150 88 A62 62 0 0 0 128.8 91.7 Z",F[4],"",0,0)}
<path d="M160.6 28.5 A122 122 0 1 1 35.4 108.3" fill="none" stroke="currentColor" stroke-width="1.3" stroke-dasharray="5 4" opacity=".7"/>
<path d="M35.4 108.3 l-1 -11 m1 11 l9 -6" stroke="currentColor" stroke-width="1.5" fill="none"/>
<text x="93" y="290" text-anchor="middle" font-style="italic">Interphase (G1 + S + G2)</text>
<line x1="134" y1="62" x2="116" y2="20" stroke="currentColor" opacity=".6"/><text x="112" y="16" text-anchor="end">Cytokinesis</text>
<text x="150" y="146" text-anchor="middle" font-weight="700">Cell</text><text x="150" y="162" text-anchor="middle" font-weight="700">cycle</text>
${leg(50,F[0],"G1","cell grows,","makes organelles and proteins")}
${leg(98,F[1],"S","DNA is replicated,","each chromosome is copied")}
${leg(146,F[2],"G2","cell grows more,","checks DNA, prepares to divide")}
${leg(194,F[3],"M","mitosis,","the nucleus divides (PMAT)")}
${leg(242,F[4],"Cytokinesis","the cytoplasm splits,","giving 2 daughter cells")}</svg>`;
  return {stages,big,cyc};
})();

DATA.core.bio.push(
{id:"cells", title:"Cell structure & organelles", group:"Genetics · Cellular (Booklet 1)",
checks:[
 "Recognise the basic cell structure and describe the nucleus, cytoplasm and the function of some organelles (nucleus, cytoplasm, mitochondria, centrioles, rough endoplasmic reticulum, ribosomes)."
],
html:`
<figure class="dg cellfig"><div class="dgrow">
<div class="dgcell"><svg viewBox="0 0 400 290" width="400" font-family="system-ui,sans-serif" font-size="12.5" fill="currentColor" role="img" aria-label="Labelled animal cell">
<path d="M200 45 C270 40 330 85 330 145 C332 210 275 250 200 248 C125 252 70 210 72 145 C70 85 130 48 200 45 Z" fill="rgba(232,105,44,.09)" stroke="currentColor" stroke-width="2"/>
<g fill="none" stroke="currentColor" stroke-width="1.6"><path d="M221 103 A48 48 0 0 1 221 177"/><path d="M226 97 A56 56 0 0 1 226 183"/><path d="M231 91 A64 64 0 0 1 231 189"/></g>
<g fill="currentColor"><circle cx="239" cy="99" r="2.3"/><circle cx="250" cy="118" r="2.3"/><circle cx="254" cy="140" r="2.3"/><circle cx="250" cy="162" r="2.3"/><circle cx="239" cy="181" r="2.3"/><circle cx="125" cy="125" r="2"/><circle cx="140" cy="210" r="2"/><circle cx="270" cy="75" r="2"/><circle cx="205" cy="225" r="2"/><circle cx="165" cy="70" r="2"/></g>
<circle cx="190" cy="140" r="38" fill="rgba(130,110,230,.2)" stroke="currentColor" stroke-width="1.8"/><circle cx="196" cy="134" r="11" fill="rgba(130,110,230,.5)"/>
<g transform="translate(115 95) rotate(-25)"><ellipse rx="24" ry="11" fill="rgba(229,72,77,.22)" stroke="currentColor" stroke-width="1.6"/><path d="M-16 0 q4 -8 8 0 q4 8 8 0 q4 -8 8 0 q4 8 8 0" fill="none" stroke="currentColor" stroke-width="1.2"/></g>
<g transform="translate(270 215) rotate(20)"><ellipse rx="24" ry="11" fill="rgba(229,72,77,.22)" stroke="currentColor" stroke-width="1.6"/><path d="M-16 0 q4 -8 8 0 q4 8 8 0 q4 -8 8 0 q4 8 8 0" fill="none" stroke="currentColor" stroke-width="1.2"/></g>
<g transform="translate(120 185)" fill="rgba(70,180,110,.35)" stroke="currentColor" stroke-width="1.4"><rect x="-14" y="-4" width="22" height="8" rx="2"/><rect x="8" y="-14" width="8" height="22" rx="2"/></g>
<g stroke="currentColor" stroke-width="1" opacity=".6"><line x1="96" y1="73" x2="106" y2="88"/><line x1="58" y1="132" x2="152" y2="132"/><line x1="72" y1="216" x2="110" y2="190"/><line x1="318" y1="46" x2="292" y2="72"/><line x1="338" y1="102" x2="245" y2="110"/><line x1="330" y1="132" x2="257" y2="139"/><line x1="332" y1="244" x2="302" y2="178"/></g>
<text x="8" y="70">Mitochondrion</text><text x="8" y="136">Nucleus</text><text x="8" y="222">Centrioles</text>
<text x="392" y="40" text-anchor="end">Cell membrane</text><text x="392" y="106" text-anchor="end">Rough ER</text><text x="392" y="136" text-anchor="end">Ribosomes</text><text x="392" y="254" text-anchor="end">Cytoplasm</text>
</svg><div class="dglab">Animal cell</div></div>
<div class="dgcell"><svg viewBox="0 0 420 290" width="420" font-family="system-ui,sans-serif" font-size="12.5" fill="currentColor" role="img" aria-label="Labelled plant cell">
<rect x="100" y="30" width="240" height="230" rx="10" fill="rgba(70,180,110,.1)" stroke="currentColor" stroke-width="4"/>
<rect x="108" y="38" width="224" height="214" rx="6" fill="none" stroke="currentColor" stroke-width="1.4"/>
<rect x="170" y="70" width="145" height="160" rx="30" fill="rgba(80,150,230,.2)" stroke="currentColor" stroke-width="1.6"/>
<circle cx="135" cy="85" r="20" fill="rgba(130,110,230,.2)" stroke="currentColor" stroke-width="1.8"/><circle cx="139" cy="81" r="6" fill="rgba(130,110,230,.5)"/>
<g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M161 95 A28 28 0 0 1 125 111"/><path d="M167 97 A34 34 0 0 1 123 117"/></g>
<g fill="currentColor"><circle cx="164" cy="103" r="2.2"/><circle cx="152" cy="115" r="2.2"/><circle cx="135" cy="120" r="2.2"/><circle cx="200" cy="242" r="2"/><circle cx="230" cy="240" r="2"/><circle cx="293" cy="244" r="2"/><circle cx="158" cy="200" r="2"/></g>
<g fill="rgba(70,180,110,.5)" stroke="currentColor" stroke-width="1.4"><ellipse cx="130" cy="150" rx="16" ry="8" transform="rotate(70 130 150)"/><ellipse cx="140" cy="225" rx="16" ry="8" transform="rotate(20 140 225)"/><ellipse cx="250" cy="54" rx="16" ry="8"/><ellipse cx="323" cy="150" rx="16" ry="7" transform="rotate(90 323 150)"/></g>
<g stroke="rgba(30,110,60,.9)" stroke-width="1.6"><line x1="244" y1="50" x2="244" y2="58"/><line x1="250" y1="49" x2="250" y2="59"/><line x1="256" y1="50" x2="256" y2="58"/></g>
<g transform="translate(135 190) rotate(80)"><ellipse rx="14" ry="7" fill="rgba(229,72,77,.22)" stroke="currentColor" stroke-width="1.4"/><path d="M-9 0 q2.5 -5 5 0 q2.5 5 5 0 q2.5 -5 5 0" fill="none" stroke="currentColor" stroke-width="1.1"/></g>
<g stroke="currentColor" stroke-width="1" opacity=".6"><line x1="64" y1="41" x2="100" y2="48"/><line x1="56" y1="86" x2="115" y2="86"/><line x1="62" y1="118" x2="125" y2="115"/><line x1="76" y1="151" x2="122" y2="150"/><line x1="92" y1="196" x2="130" y2="192"/><line x1="70" y1="268" x2="108" y2="240"/><line x1="362" y1="106" x2="290" y2="110"/><line x1="350" y1="191" x2="326" y2="195"/><line x1="348" y1="241" x2="295" y2="244"/></g>
<text x="8" y="45">Cell wall</text><text x="8" y="90">Nucleus</text><text x="8" y="122">Rough ER</text><text x="8" y="155">Chloroplast</text><text x="8" y="200">Mitochondrion</text><text x="8" y="280">Cell membrane</text>
<text x="412" y="110" text-anchor="end">Vacuole</text><text x="412" y="195" text-anchor="end">Cytoplasm</text><text x="412" y="245" text-anchor="end">Ribosomes</text>
</svg><div class="dglab">Plant cell</div></div>
</div><figcaption><b>Compare</b>Both have a nucleus, cytoplasm, cell membrane, mitochondria, ribosomes and rough ER. Only plant cells have a <b style="all:unset;font-weight:700">cell wall</b> (cellulose, for support), <b style="all:unset;font-weight:700">chloroplasts</b> (photosynthesis) and one large permanent <b style="all:unset;font-weight:700">vacuole</b> (stores cell sap, keeps the cell firm). Centrioles are drawn in animal cells only. Simplified diagrams, not to scale.</figcaption></figure>
<table><tr><th>Structure</th><th>Function</th></tr>
<tr><td>Nucleus</td><td>Control centre. Holds the DNA (as chromosomes) and controls the cell's activities.</td></tr>
<tr><td>Cytoplasm</td><td>Jelly-like fluid where most chemical reactions happen. Holds the organelles.</td></tr>
<tr><td>Cell membrane</td><td>Controls what enters and leaves the cell.</td></tr>
<tr><td>Mitochondria</td><td>Site of cellular respiration, releasing energy (ATP) from glucose.</td></tr>
<tr><td>Centrioles</td><td>Pair of cylinders near the nucleus (animal cells). Organise the spindle microtubules during cell division.</td></tr>
<tr><td>Rough endoplasmic reticulum (RER)</td><td>Membranes studded with ribosomes. Transports proteins made by the ribosomes.</td></tr>
<tr><td>Ribosomes</td><td>Tiny dots where proteins are made from amino acids.</td></tr>
<tr><td>Cell wall <small>(plant only)</small></td><td>Tough outer layer made of cellulose, outside the cell membrane. Supports the cell, gives it a fixed shape and stops it bursting when it takes in water.</td></tr>
<tr><td>Chloroplast <small>(plant only)</small></td><td>Green organelle containing chlorophyll. Site of photosynthesis, where light energy is used to make glucose from carbon dioxide and water.</td></tr>
<tr><td>Vacuole <small>(large and permanent in plants)</small></td><td>Fluid-filled sac of cell sap (water, sugars, salts). Stores substances and keeps the cell firm (turgid), which helps the plant stay upright.</td></tr></table>
<div class="exam"><b>From past papers</b> You get a labelled animal-cell drawing with X pointing at the nucleus and Y at the centriole pair, then you name each one and give its function.</div>`,
kw:["nucleus","cytoplasm","mitochondria","centriole","rough endoplasmic reticulum","ribosome"],
cards:[["Which organelle makes proteins?","Ribosomes (many sit on the rough ER)."],["What do centrioles do?","Organise the spindle microtubules that pull chromosomes apart during division."],["Where is energy released?","Mitochondria, by cellular respiration."],["What does the cell wall do?","Supports the cell and keeps its shape. Made of cellulose, plant cells only."],["Where does photosynthesis happen?","Chloroplasts, which contain chlorophyll (plant cells only)."],["What does the vacuole do?","Stores cell sap and keeps the plant cell firm (turgid)."]]},

{id:"dna", title:"Chromosomes, genes, DNA & nucleotides", group:"Genetics · Cellular (Booklet 1)",
checks:[
 "Distinguish between chromosomes, genes and DNA.",
 "Describe the structure of a nucleotide (sugar, phosphate, nitrogen-containing base).",
 "Describe a DNA molecule: double helix, complementary base pairing (with base names), sugar-phosphate backbone, hydrogen bonding.",
 "Describe proteins as a string of amino acids whose order is determined by DNA."
],
html:`
<div class="flow"><span>DNA</span><i>is coiled around histone proteins into</i><span>Chromosomes</span><i>which carry many</i><span>Genes</span><i>which each code for a</i><span>Protein</span></div>
<ul class="notes">
<li><b>DNA</b> is the molecule that carries genetic instructions.</li>
<li>A <b>gene</b> is a section of DNA that codes for one protein (and so one trait).</li>
<li>A <b>chromosome</b> is one long, tightly coiled DNA molecule wrapped around proteins. Humans have 46 (23 pairs).</li>
<li>A <b>nucleotide</b> is one DNA building block: a <b>phosphate</b>, a <b>deoxyribose sugar</b> and a <b>nitrogen-containing base</b>.</li>
<li>DNA is a <b>double-stranded helix</b>. The <b>sugar-phosphate backbone</b> forms the outside rails, and the bases point inward and join by <b>hydrogen bonds</b>.</li>
<li><b>Complementary base pairing:</b> Adenine pairs with Thymine (A–T), and Guanine pairs with Cytosine (G–C).</li>
<li>Every 3 bases (a triplet) code for one <b>amino acid</b>. The order of bases sets the order of amino acids, which sets the protein's shape and job.</li>
</ul>
<div class="tip"><b>Shortcut</b> Writing a complementary strand: swap A↔T and G↔C. So TAGTAACG becomes ATCATTGC.</div>
<div class="exam"><b>From past papers</b> One multiple-choice question gives TAGTAACG and asks for its complement. Another shows DNA unwinding off histones with triplets labelled TGA, CTG and ACT. There's also a matching exercise on DNA terms.</div>`,
kw:["chromosome","gene","DNA","nucleotide","double stranded helix","sugar-phosphate backbone","base","base pair","complementary base pair","complementary strand","Adenine (A)","Guanine (G)","Cytosine (C)","Thymine (T)","hydrogen bond","deoxyribose sugar","protein","amino acid"],
cards:[["3 parts of a nucleotide?","Phosphate, deoxyribose sugar, nitrogen-containing base."],["Base pairing rules?","A–T and G–C."],["What holds the two strands together?","Hydrogen bonds between complementary bases."],["Gene vs chromosome?","A gene is one section of DNA coding for a protein. A chromosome is a whole coiled DNA molecule carrying many genes."]]},

{id:"cycle", title:"The cell cycle & mitosis", group:"Genetics · Cellular (Booklet 1)",
checks:[
 "Describe the cell cycle (interphase including G1, S, G2, mitosis/meiosis, cytokinesis).",
 "State the order of the phases of mitosis and briefly explain what happens in each.",
 "Identify the phase of mitosis in cell images.",
 "Draw simple, correctly labelled diagrams of mitosis."
],
html:`
<div class="flow"><span>G1: cell grows</span><i>→</i><span>S: DNA replicated</span><i>→</i><span>G2: grows, prepares</span><i>→</i><span>Mitosis</span><i>→</i><span>Cytokinesis</span></div>
<p>G1, S and G2 together make up <b>interphase</b>, the longest stage. DNA quantity doubles during S (e.g. from 2 to 4 units) and halves again after division.</p>
<figure class="dg cycfig"><div class="dgart">${MIT.cyc}</div><figcaption><b>Cell cycle</b>Read it clockwise from the top. Interphase (G1, S, G2) takes up most of the cycle. Mitosis (M) and cytokinesis are short. Segment sizes show roughly how long each stage takes and are not exact.</figcaption></figure>
<table><tr><th>Phase (PMAT)</th><th>What happens</th><th>How to spot it</th></tr>
<tr><td><b>Prophase</b></td><td>Chromosomes condense into X shapes (2 sister chromatids joined at a centromere). The nuclear membrane breaks down. Centrioles move to the poles and spindle fibres form.</td><td>Thick X-shaped chromosomes scattered around, spindle starting to form</td></tr>
<tr><td><b>Metaphase</b></td><td>Chromosomes line up single-file across the equator. Spindle fibres attach at the centromeres.</td><td>A neat line across the middle</td></tr>
<tr><td><b>Anaphase</b></td><td>Sister chromatids are pulled apart to opposite poles.</td><td>V-shapes moving away from the middle</td></tr>
<tr><td><b>Telophase</b></td><td>Chromatids reach the poles, and two new nuclear membranes form.</td><td>Two clusters at opposite ends, the cell starting to pinch</td></tr>
<tr><td><b>Cytokinesis</b></td><td>The cytoplasm divides, giving 2 identical diploid daughter cells.</td><td>Cell fully pinched into two</td></tr></table>
<figure class="dg mitfig"><div class="mstages">${MIT.stages}</div><figcaption><b>Mitosis stages</b>Shown with 4 chromosomes (2 pairs, matched by colour and size). Green crosses are centrioles, and thin grey lines are spindle fibres. Each daughter cell ends up with the same 4 chromosomes as the parent.</figcaption></figure>
<figure class="dg bigfig"><div class="dgart">${MIT.big}</div><figcaption><b>Labelled metaphase</b>These are the labels to practise when drawing a mitosis stage. Use single pencil lines, no shading, and ruled label lines.</figcaption></figure>
<div class="tip"><b>Drawing tips</b> Use a pencil, draw clean single lines and no shading, and label with ruled lines. Labels to include: cell membrane, chromosome/chromatid, centromere, spindle fibres, centriole, nuclear membrane (where present).</div>
<div class="exam"><b>From past papers</b> You get sets of 4–6 cell drawings to name or put in order (interphase, prophase, metaphase, anaphase, telophase/cytokinesis), a DNA-quantity-through-the-cycle graph, and a circular cell-cycle diagram labelled A–D.</div>`,
kw:["interphase (G1, S, G2)","cell cycle","mitosis","cytokinesis","prophase","metaphase","anaphase","telophase","chromatid","sister chromatids","centromeres","centriole","spindle microtubules","daughter cells"],
cards:[["What happens in S phase?","DNA is replicated (copied), so the DNA quantity doubles."],["Order of mitosis?","Prophase, Metaphase, Anaphase, Telophase (PMAT), then cytokinesis."],["Chromosomes on the equator?","Metaphase."],["Sister chromatids pulled apart?","Anaphase."],["What does mitosis produce?","2 genetically identical diploid daughter cells."]]},

{id:"mutation", title:"Mutagens, mutations & cancer", group:"Genetics · Cellular (Booklet 1)",
checks:[
 "Describe what a mutagen is and state briefly how mutagens cause mutations (e.g. UV damage, toxins, some viruses).",
 "Understand the consequences of a mutation.",
 "Describe cancer as a malfunction of the control of the cell cycle."
],
html:`
<ul class="notes">
<li>A <b>mutation</b> is a permanent change in the DNA base sequence.</li>
<li>A <b>mutagen</b> is anything that causes a mutation. <b>UV radiation</b> damages the DNA bases, <b>toxins</b> such as tobacco smoke and asbestos chemically alter DNA, and <b>some viruses</b> (e.g. HPV) insert their DNA into ours.</li>
<li><b>Consequences:</b> a mutation can be harmful (a faulty protein, e.g. sickle-cell anaemia), neutral (no change to the protein), or occasionally helpful (new variation that natural selection can act on). Mutations in gametes are passed on to offspring. Mutations in body cells are not.</li>
<li><b>Cancer</b> happens when mutations damage the genes that control the cell cycle, so cells divide uncontrollably and form a <b>tumour</b>.</li>
<li><b>Benign</b> tumours stay in one place and don't spread. <b>Malignant</b> tumours invade tissue and spread around the body (metastasis).</li>
</ul>
<div class="exam"><b>From past papers</b> One question has a graph of healthy cells vs cancer cells after drug doses F–I. Treatment kills both kinds because the drugs target any rapidly dividing cell, which is why healthy-cell numbers dip after each dose. Another shows normal vs sickle-shaped red blood cells.</div>`,
kw:["mutation","mutagen","cancer","benign","malignant"],
cards:[["Define mutagen","Any agent that causes a change in DNA, e.g. UV light, toxins, some viruses."],["Benign vs malignant?","Benign stays put. Malignant invades and spreads."],["Why is cancer a cell-cycle problem?","Mutations disable the controls that stop division, so cells divide uncontrollably."]]},

{id:"meiosis", title:"Haploid, diploid, meiosis & fertilisation", group:"Genetics · Cellular (Booklet 1)",
checks:[
 "Draw and explain a simplified diagram showing how haploid cells arise from diploid cells.",
 "Describe how, at fertilisation, the diploid number is restored through fusion of gametes.",
 "State the order of the phases of meiosis and briefly explain what happens in each.",
 "Identify the phase of meiosis in cell images.",
 "Draw simple, correctly labelled diagrams of meiosis."
],
html:`
<ul class="notes">
<li><b>Diploid (2n)</b> means 2 sets of chromosomes, e.g. human body cells with 46. <b>Haploid (n)</b> means 1 set, e.g. gametes with 23.</li>
<li><b>Meiosis</b> makes <b>4 genetically different haploid gametes</b> from one diploid cell, through two divisions.</li>
<li>At <b>fertilisation</b> a haploid sperm (n=23) fuses with a haploid egg (n=23), making a diploid <b>zygote</b> (2n=46).</li>
</ul>
<table><tr><th>Phase</th><th>What happens</th></tr>
<tr><td>Prophase I</td><td>Homologous chromosomes pair up. <b>Crossing over</b> swaps sections between them, creating variation.</td></tr>
<tr><td>Metaphase I</td><td><b>Homologous pairs</b> line up on the equator (in pairs, not single-file).</td></tr>
<tr><td>Anaphase I</td><td>Homologous pairs separate to opposite poles. The chromatids stay together.</td></tr>
<tr><td>Telophase I + cytokinesis</td><td>2 haploid cells form.</td></tr>
<tr><td>Prophase II → Telophase II</td><td>Like mitosis: chromosomes line up single-file, sister chromatids separate, and you end with <b>4 haploid cells</b>.</td></tr></table>
<table><tr><th></th><th>Mitosis</th><th>Meiosis</th></tr>
<tr><td>Divisions</td><td>1</td><td>2</td></tr><tr><td>Cells made</td><td>2 diploid</td><td>4 haploid</td></tr>
<tr><td>Genetically</td><td>Identical</td><td>Different</td></tr><tr><td>Purpose</td><td>Growth, repair</td><td>Making gametes</td></tr></table>
<div class="tip"><b>Spot the difference</b> In metaphase I chromosomes sit in pairs side by side on the equator. In mitosis metaphase and metaphase II they sit single-file.</div>
<div class="exam"><b>From past papers</b> "What process is depicted?" with a pinched cell holding two nuclei and duplicated chromosomes. Another question gives a chromosome-number table (fruit fly 8, human 46, tomato 24) and asks for the gamete number, which is half.</div>`,
kw:["haploid","diploid","gamete","fertilisation","meiosis","homologous pairs","crossing over","zygote"],
cards:[["Human gamete chromosome number?","23 (haploid)."],["Meiosis produces?","4 genetically different haploid cells."],["How is the diploid number restored?","Fertilisation: two haploid gametes fuse to form a diploid zygote."],["When does crossing over happen?","Prophase I of meiosis."]]}
);
