KEYS.ext2025 = {
mc:"1D 2C 3D 4D 5A 9A 11A 12B",
why:{2:"WB × WW gives WB, WB, WW, WW, so 50% are heterozygous."},
sa:[
["a) Describe the process of crossover and predict",2,"swap|exchange|cross;variation|diversity|different|unique|new combination","In prophase I, homologous chromosomes pair up and swap sections of DNA (crossing over). This makes new combinations of alleles, so the gametes are all different and genetic variation in the population increases."],
["b) Suggest an advantage for a population that has high levels",1,"disease|environment|adapt|surviv|change","With more variation, some individuals are likely to survive a new disease or environmental change, so the population is less likely to die out."],
["a) Using a Punnett-square show the probability",4,"r:x\\s*\\^?\\s*b\\s*x\\s*\\^?\\s*b|xbxb;100;w:0|none|zero;carrier","Vera XbXb × Terry XBY gives XBXb, XBXb, XbY, XbY. Sons: 100% colourblind. Daughters: 0% colourblind (all are carriers)."],
["b) Explain how 2 non-affected parents can have a child",2,"carrier|heterozygous;mother|mum|female|son","The mother can be an unaffected carrier (XBXb). She can pass her recessive Xb to a son, who has no second X to mask it, so he is affected."],
["c) Explain why females can be carriers for X-linked conditions",2,"two x|2 x|two copies|xx|second x;one x|only one|single x|w:y|y chromosome","Females have two X chromosomes, so a dominant normal allele on one X can hide the recessive allele on the other. Males have only one X (plus a Y), so if they have the allele, it is always expressed."],
["a) Describe how this event demonstrates genetic drift",1,"chance|random|luck","The cyclone killed lizards at random. The survivors happened to have darker skin by chance, not because dark skin helped them survive."],
["b) Suggest how the allele frequency of the darker skin colour",2,"increase|more common|higher|100;surviv|only|reproduc|pass|offspring","It will increase (possibly to 100%), because the survivors that reproduce mostly carry the dark-skin alleles and pass them to their offspring."],
["a) A student carried out both reactions",2,"w:x|line x;more chloride|2agcl|two|more agcl|more product|more cl|2 mol|twice","X. Per gram, CaCl2 contains more chloride ions than NaCl (2 Cl per formula unit), so it makes more silver chloride, giving the higher plateau."],
["b) As seen on the graph neither reaction lines are linear",3,"fast|steep|high concentration|most collision;slow|decreas|fewer|less;stop|finish|complete|used up|plateau|flat|constant","A: steepest part, fastest rate, because reactant concentration is highest and collisions are most frequent. B: the line curves as reactants are used up, so there are fewer collisions and the rate slows. C: the line is flat because a reactant (the chloride salt) has run out, so no more AgCl forms."],
["Question 13",2,"conduct;metal|plastic|insulat|better|faster","Metal is a much better thermal conductor than plastic, so heat from the surroundings is conducted through the metal bowl into the ice cream faster."]
]};

KEYS.ext2024 = {
mc:"1A 2D 3B 4B 5A 8B 9B 10B 11A 14D",
why:{1:"Mother XhXh × father XHY: every daughter gets the father's XH, so 0% are affected.",13:"D: the mass stays the same and it doesn't change the mass of products."},
sa:[
["a) Complete the table below.",4,"~XHXH;~XHXh;affected|haemophilia|hemophilia;male","XhXh = female, haemophilia. XHY = male, normal. Female normal (non-carrier) = XHXH. XhY = male, haemophilia. Female normal (carrier) = XHXh."],
["b) A male that has haemophilia has a male child",2,"w:y|y chromosome;daughter|w:x|x chromosome","A father gives his son a Y chromosome, not an X. The haemophilia allele is on his X, which only goes to his daughters."],
["a) Complete the table below showing the genotypes",3,"~XNXn|carrier;~XnXn;~Xn","2 = XNXn (carrier). 7 = XnXn. 10 = XnXn if female or XnY if male (affected either way)."],
["b) Explain why all the offspring of individuals 4 and 5",2,"both affected|4 and 5|both parents|affected parents;only.*xn|only have xn|only pass|no normal|homozygous|xnxn|all.*xn","Father 4 is XnY and mother 5 is XnXn. The mother can only pass on Xn, so every son is XnY. Every daughter gets Xn from both parents (XnXn), so all children are affected."],
["a) What is a genetic bottleneck, and how has it affected",2,"reduc|small|decreas|few;diversity|variation|allele|gene pool|inbreed","A sudden, sharp drop in population size (e.g. from a disaster) that leaves only a few survivors and a small gene pool. Cheetahs now have very low genetic diversity and suffer from inbreeding."],
["b) How does the lack of genetic diversity make cheetahs",2,"same|similar|identical|no variation|lack;all affected|resist|suscept|wipe|die|adapt|vulnerab","Because the cheetahs are so genetically similar, if one is vulnerable to a disease or change they all are. Few or none will have alleles that let them resist it and survive."],
["b) Suggest a natural resource from which hydrogen",1,"water|natural gas|methane|fossil","Natural gas (methane) or water."],
["c) The Haber process uses a catalyst to speed up",2,"activation energy|lower;alternative|pathway|more successful|more collision|more particles","A catalyst provides an alternative reaction pathway with a lower activation energy, so more collisions are successful and the reaction is faster (the catalyst isn't used up)."]
]};

KEYS.ext2023 = {
mc:"1C 2B 3D 4B 5B 6C 7C 8C 9B 10D",
sa:[
["Question 1 (4 marks)",4,"","Prophase I = C. Metaphase II = B. Anaphase I = A. Telophase II = D."],
["Question 2 (2 marks)",2,"swap|exchange;variation|divers|unique|new combination","In prophase I, homologous chromosomes swap sections of DNA. This makes new combinations of alleles on each chromosome, so every gamete is genetically unique, which increases genetic diversity."],
["Question 3 (3 marks)",3,"50;carrier|~XAXa|~XBXb|~XHXh;affected","Carrier female (XAXa) × affected male (XaY) gives XAXa, XaXa, XAY, XaY. 50% of children inherit the trait: half the daughters are affected (the rest are carriers) and half the sons are affected."],
["Question 4 (3 marks)",3,"~XbY|colour blind son|colorblind son|son;carrier;100|w:0","XBXb × XBY gives XBXB, XBXb, XBY, XbY. Female offspring: 100% normal vision (50% are carriers). One in two sons is colour blind."],
["a. Name the independent variable",1,"concentration","The concentration of the hydrochloric acid."],
["b. State three ways in which the method can be improved",3,"same mass|mass;same size|particle size|surface area|powder|lumps;volume|temperature","Use the same mass of calcium carbonate, the same particle size (both powder or both lumps), and the same volume and temperature of acid. Only the acid concentration should change."],
["c. How can the design be changed to ensure the results are reliable",1,"repeat|trial|replicate|more times|average","Repeat each concentration several times and average the results."],
["d. Is the method valid? Explain.",2,"no|not valid|invalid;more than one|several variables|not controlled|uncontrolled|multiple|other variables","No. More than one variable was changed between the flasks, so you can't tell whether any difference was caused by the acid concentration."],
["e. Based on the chemistry involved, explain the expected outcome",2,"higher concentration|more concentrated|increase;collision","The higher the acid concentration, the faster the reaction (mass decreases faster), because there are more acid particles in the same volume, so collisions are more frequent."],
["a. Explain why the gradient of the graph decreases",2,"used up|less magnesium|fewer|decreas|concentration;collision","As magnesium (and acid) is used up, there are fewer reactant particles, so collisions are less frequent and the rate (gradient) decreases."],
["b. From the graph how can you determine when the reaction has ceased",1,"flat|horizontal|level|constant|plateau|stops changing|no longer","When the line becomes flat (horizontal), meaning the mass stops changing."],
["c. What caused the reaction to cease",1,"magnesium|ran out|used up|limiting","The magnesium (the limiting reactant) was used up."],
["d. Calculate the gradient of the line in the first 0.5min",2,"0.03|0.028|0.029|0.031|0.032|0.027|0.026|0.025|0.024;0.5|÷|/","Gradient = change in mass ÷ time ≈ (124.39 − 124.375) ÷ 0.5 ≈ 0.03 g/min. Use the readings on your printed graph, because the values here are estimated."],
["e. What would be the unit for your gradient calculation",1,"g/min|g min|grams per minute|g per min|gmin","g/min (grams per minute)."]
]};

KEYS.ext2022 = {
mc:"1A 2B",
why:{2:"Reversed, the products start at 40 and finish at 50, so ΔH = +10."},
sa:[
["(a) Does the graph indicate that this is an exothermic",1,"exo","Exothermic."],
["(b) Using your knowledge about chemical reactions explain",3,"activation|absorb|break|input;release|form|new bond;more|net|lower|negative|-10|−10","Energy is absorbed to break the bonds in the reactants (the activation energy, about 50 kJ mol⁻¹). Energy is released when new bonds form in the products (about 60 kJ mol⁻¹). More is released than absorbed, so the products are lower in energy and ΔH ≈ −10 kJ mol⁻¹."],
["3. Calculate the enthalpy change",3,"","Use ΔH = energy to break bonds − energy released forming bonds, with the bond energies from your data booklet. For 2C2H6 + 7O2 the answer is a large negative value (combustion of ethane is about −1560 kJ per mole, so about −3120 kJ for 2 mol). Check against your booklet values."],
["(a) Draw the molecular structure for this compound",3,"","For example 1-chlorobutane: a chain of 4 carbons with single bonds, 9 hydrogens, and Cl on the end carbon. Every C has 4 bonds, and H and Cl each have 1."],
["(b) Is this a saturated or unsaturated molecule",2,"saturated;single","Saturated: it has only single bonds between carbon atoms."],
["(b) The molecule C4H9Cl has a few isomers",1,"same molecular formula|same formula|same number;different structur|different arrangement|different shape","Isomers have the same molecular formula but a different structural arrangement of atoms."],
["(c) For the molecule that you drew in (a) draw an isomer",2,"","For example 2-chlorobutane (Cl on the second carbon), or 2-chloro-2-methylpropane."],
["(a) Balance the equation above",1,"31|15.5;20co2|10co2;24h2o|12h2o","2C8H18 + 2C2H5OH + 31O2 → 20CO2 + 24H2O (or C8H18 + C2H5OH + 15.5O2 → 10CO2 + 12H2O)."],
["(b) Ethanol is a biofuel, what does this mean",1,"renewable|plant|biomass|crop|sugar|living|organic","It is made from renewable biological material such as plant crops (e.g. by fermenting sugar)."],
["(c) What are the ‘environmental effects of fossil fuels’",2,"carbon dioxide|co2|greenhouse|global warming|climate;pollut|smog|acid rain|sulfur|non-renewable|monoxide|particulate","Releasing carbon dioxide, which adds to the greenhouse effect and climate change, plus air pollution such as smog, carbon monoxide and acid rain from sulfur oxides."],
["(a) The Grevy’s zebra is one species",1,"interbreed|breed;fertile","A group of organisms that can interbreed and produce fertile offspring."],
["(b) Use the information above, and your knowledge, to explain",2,"reduc|decrease|15,200|15200|2000|drop|small;variation|diversity|allele|gene pool","A genetic bottleneck is a sharp fall in population size, here from about 15,200 to fewer than 2000 zebras. The few survivors carry only some of the original alleles, so genetic diversity is reduced."],
["(i) Explain the term ‘founder effect’",2,"small group|small number|new population|few individuals|founded;allele|gene pool|not represent|less variation|frequenc","A small group starts a new population, carrying only a small, unrepresentative sample of the original alleles. The Tsavo zebras came from a few introduced animals, so they have low genetic diversity."],
["(ii) Why is the founder effect a disadvantage",2,"variation|diversity|inbreed;adapt|surviv|vulnerab|suscept|extinct|disease","Low genetic variation and inbreeding mean the population is less able to adapt to disease or environmental change, so it is more likely to die out."],
["a) Explain the difference between genetic drift and genetic flow",2,"random|chance;migrat|movement|move|interbreed","Genetic drift is a random change in allele frequencies due to chance events, strongest in small populations. Gene flow is the movement of alleles between populations when individuals migrate and interbreed."],
["b) Give an example of genetic drift and genetic flow",2,"bottleneck|founder|disaster|fire|flood|storm|cyclone|by chance;migrat|move|pollen|interbreed|join","Drift: a bushfire randomly kills most of a population, changing which alleles remain. Flow: zebras migrating to a new herd and breeding there, bringing in new alleles."]
]};
