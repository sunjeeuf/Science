/* ================= 2023 CORE ================= */
dg("core2023","^\\s*12\\. The following diagram shows cells", G.cells([["meta","A"],["telo","B"],["ana","C"],["pron","D"]]),
  "Redrawn from the descriptions. Your two sets of files describe drawing C differently (one says chromatids moving apart, the other says chromosomes lined up), so check C on your printed paper.");
dg("core2023","^\\s*13\\. The simplified pedigree chart", G.pedigree({w:420,h:270,people:[{id:1,x:110,y:40,s:"f",a:1},{id:2,x:200,y:40,s:"m"},{id:3,x:155,y:140,s:"f"},{id:4,x:255,y:140,s:"m"},{id:5,x:150,y:240,s:"m",a:1},{id:6,x:205,y:240,s:"f"},{id:7,x:260,y:240,s:"f",a:1}],
  couples:[[1,2],[3,4]],kids:[{p:[1,2],k:[3]},{p:[3,4],k:[5,6,7]}]}),
  "Redrawn: an affected woman and an unaffected man have an unaffected daughter. She and an unaffected man have both affected and unaffected children. The exact third generation is approximate.");
dg("core2023","^\\s*14\\.\\s*The karyotype diagram", G.karyo({sex:"XY"}), "Redrawn: chromosome pairs 1 to 22 plus one X and one Y.");
dg("core2023","^\\s*16\\. The graph below shows how the mass of DNA", G.graph({xmax:32,ymax:5,noscale:0,yt:[0,1,2,3,4,5],xt:[],xlab:"Time",ylab:"Quantity of DNA (units)",
  curves:[{lin:1,pts:[[0,2],[10,2],[16,4],[22,4],[26,4],[26.4,2],[32,2]]}],lab:[{x:5,y:2.3,t:"G₁"},{x:13,y:3.4,t:"S"},{x:19,y:4.3,t:"G₂"},{x:24,y:4.3,t:"Mitosis"},{x:11,y:4.75,t:"⟵ Interphase ⟶"}]}),
  "Redrawn: DNA stays at 2 units in G₁, rises to 4 in S, stays at 4 through G₂ and mitosis, then drops back to 2.");
dg("core2023","^\\s*25\\. Hydrogen peroxide", G.graph(H2O2), H2O2note);
dg("core2023","^\\s*Question 1\\b", (()=>{let s=`<path d="M60,90 C40,30 150,10 220,30 C300,50 330,120 290,170 C250,220 120,220 80,180 C55,155 70,120 60,90Z" fill="#f6c99a" fill-opacity=".45"/>`;
  s+=`<circle cx="175" cy="110" r="38" fill="#9db8e6" fill-opacity=".6"/><path d="M160,100 q8,-12 16,0 t16,2 M158,118 q8,8 16,0 t16,0" stroke-width="1.2"/>`;
  s+=`<ellipse cx="110" cy="150" rx="18" ry="9" fill="#e8a07a" transform="rotate(-20 110 150)"/><ellipse cx="250" cy="80" rx="18" ry="9" fill="#e8a07a" transform="rotate(30 250 80)"/><ellipse cx="240" cy="160" rx="16" ry="8" fill="#e8a07a"/>`;
  s+=`<path d="M100,70 q20,-8 40,0 M98,80 q22,-8 44,0" stroke-width="1.4"/>`+[[120,105],[130,170],[205,175],[265,120],[95,115]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.5" fill="currentColor"/>`).join("");
  s+=`<g stroke="#b08a00" stroke-width="5"><line x1="225" y1="50" x2="240" y2="50"/><line x1="232" y1="40" x2="232" y2="58"/></g>`;
  s+=`<line x1="245" y1="48" x2="320" y2="20" stroke-width="1.2"/>`+G.T(328,24,"Y",{b:1,s:15,a:"start"});
  return G.svg(360,230,s);})(), "Redrawn: an animal cell with a nucleus, mitochondria, membranes, ribosomes and Y pointing to the centriole pair. X isn't shown because your two sets of files disagree on where it points (cell membrane in one, nucleus in the other), so check X on your printed paper.");
dg("core2023","^\\s*Question 3\\b", G.cells([["inter","S"],["telo","T"],["pro","U"],["meta","V"],["ana","W"]]), "Redrawn from the descriptions of drawings S, T, U, V and W.");
dg("core2023","^\\s*Question 4\\b", G.graph({xmax:80,ymax:1800,xt:[0,10,20,30,40,50,60,70,80],yt:[0,400,800,1200,1600],xlab:"Time (days)",ylab:"Cells per unit blood volume",
  curves:[{pts:[[0,1500],[3,1500],[8,900],[20,1450],[24,1450],[29,880],[41,1400],[45,1400],[50,850],[62,1450],[66,1450],[71,820],[80,1550]],color:"#2f7d4f",label:"healthy cells",lx:12,ly:1650},
          {dash:1,pts:[[0,600],[3,600],[8,360],[20,420],[24,420],[29,220],[41,250],[45,250],[50,90],[62,110],[66,110],[71,20],[80,40]],color:"#c2551f",label:"cancer cells",lx:30,ly:420}],
  lab:[{x:3,y:1730,t:"F"},{x:24,y:1730,t:"G"},{x:45,y:1730,t:"H"},{x:66,y:1730,t:"I"}],vl:[]}),
  "Redrawn, shape only: after each drug dose (F, G, H, I) both cell types fall, then healthy cells recover while cancer cells keep going down. The exact numbers and dose days are approximate.");
dg("core2023","^\\s*Question 5\\b", G.table(["","Organism","Number of chromosomes in each body cell"],[["Animals","fruit fly","8"],["","goat","60"],["","human","46"],["Plants","tomato","24"],["","potato","44"],["","rice","24"]]), "Table from the paper.");
dg("core2023","^\\s*Question 7\\b", G.punnett(), "Type the alleles into the headers and cells.");
dg("core2023","^\\s*Question 8\\b", G.karyo({sex:"XXY"}), "Redrawn: chromosome pairs 1 to 22, then two X chromosomes and one Y.");
dg("core2023","^\\s*Question 10\\b", G.tree({t:55,c:["Hippopotamus",{t:50,c:["Pakicetus",{t:36,c:["Humpback whale",{t:12,c:["Killer whale",{t:5,c:["Common bottlenose dolphin","Burrunan dolphin"]}]}]}]}]},{w:600,lw:200,rowH:30,rootLab:"Ancestral land mammal",time:{max:60,ticks:[55,50,36,5,0],lab:"Millions of years ago"}}),
  "Redrawn: the order of branches matches the paper. The paper also has a 210 mya marker, and the killer whale's branch time wasn't given, so those are approximate.");
dg("core2023","^\\s*b\\) The graph below, shows the reaction of HCl", G.graph({xmax:100,ymax:70,xt:[],yt:[0,10,20,30,40,50,60,70],xlab:"Time (s)",ylab:"Volume of gas (mL)",
  curves:[{f:x=>60*(1-Math.exp(-x/22)),color:"#c2551f",label:"Reaction 1",lx:62,ly:50},{f:x=>60*(1-Math.exp(-x/8)),color:"#2f7d4f",label:"Reaction 2",lx:22,ly:64}]}),
  "Redrawn: both reactions level off at about 60 mL, and Reaction 2 rises more steeply. The time scale isn't known.");
dg("core2023","^\\s*Question 12\\b", (()=>{let s=`<line x1="20" y1="40" x2="20" y2="190" stroke-width="4"/><line x1="560" y1="40" x2="560" y2="190" stroke-width="4"/><line x1="20" y1="50" x2="560" y2="50"/>`;
  s+=`<rect x="200" y="44" width="60" height="12" rx="3" fill="var(--card)"/><rect x="290" y="44" width="60" height="12" rx="3" fill="var(--card)"/>`+G.T(275,36,"straws",{s:11.5});
  s+=`<path d="M215,56 L215,70 M335,56 L335,70" stroke-width="1"/><path d="M190,95 C190,62 360,62 360,95 C360,128 190,128 190,95Z" fill="#e88a8a" fill-opacity=".6"/><path d="M190,95 l-18,-6 l0,12 Z" fill="#e88a8a"/>`+G.T(275,99,"balloon",{s:11.5});
  s+=`<path d="M160,95 l-40,0 m8,-6 l-8,6 l8,6" stroke-dasharray="4 3"/>`+G.T(120,82,"air out",{s:11});
  s+=`<path d="M250,124 L265,160 M300,124 L285,160" stroke-width="1"/><rect x="255" y="160" width="40" height="26" fill="currentColor" fill-opacity=".7"/>`+G.T(310,178,"mass",{a:"start",s:11.5})+G.T(450,40,"string",{s:11.5});
  return G.svg(580,200,s);})(), "Redrawn: a balloon taped under two straws threaded on a level string between two supports, with a mass hanging from the balloon. The table of results is in the question text.");

/* ================= 2023 EXT ================= */
dg("ext2023","^\\s*Question 5\\b", (()=>{const fl=(x,lab,big)=>{let s=`<rect x="${x-70}" y="150" width="140" height="30" rx="4"/><rect x="${x-35}" y="158" width="70" height="14" fill="#9bd3a8" fill-opacity=".5"/>`+G.T(x,169,"0.00 g",{s:11})+`<path d="M${x-14},40 L${x-14},80 L${x-55},145 L${x+55},145 L${x+14},80 L${x+14},40" fill="#bcd4f0" fill-opacity=".35"/>`;
  s+= big? [[-25,132],[0,128],[22,134],[-8,138]].map(([dx,y])=>`<path d="M${x+dx-9},${y+8} l4,-12 l12,-2 l6,10 l-6,7 Z" fill="#ddd" />`).join("") : [...Array(28)].map((_,i)=>`<circle cx="${x-38+(i*11)%78}" cy="${140-Math.floor(i/7)*3}" r="1.8" fill="currentColor"/>`).join("");
  return s+G.T(x,200,lab,{b:1});};
  return G.svg(420,215, fl(110,"flask 1",1)+fl(310,"flask 2",0));})(),
  "Redrawn: two conical flasks on digital balances, flask 1 with large lumps of calcium carbonate and flask 2 with powder. Heads up: this question's aim and method were part of an image and couldn't be read, so you'll need your printed paper to answer it.", 1);
dg("ext2023","^\\s*Question 6\\b", G.graph({xmax:7,ymin:124.30,ymax:124.40,xt:[0,1,2,3,4,5,6,7],yt:[124.30,124.32,124.34,124.36,124.38,124.40],xlab:"Time (minutes)",ylab:"Mass of flask (g)",
  curves:[{dots:1,pts:[[0,124.39],[0.5,124.376],[1,124.367],[1.5,124.36],[2,124.356],[2.5,124.353],[3,124.351],[3.5,124.35],[4,124.35],[5,124.35],[6,124.35],[7,124.35]]}]}),
  "Redrawn. Known readings: about 124.39 g at 0 min, flattening to about 124.35 g by 3.5 to 4 min. The in-between points (including at 0.5 min) are estimates, so use your printed graph for part d.", 1);

/* ================= 2022 CORE ================= */
dg("core2022","^\\s*16\\. The curve below", G.graph({xmax:10,ymax:10,noscale:1,xlab:"Time",ylab:"Volume of CO₂",curves:[{f:x=>8.5*(1-Math.exp(-x/2.4))}]}), "Redrawn: the line rises steeply, then flattens. There's no scale on the original.");
dg("core2022","^\\s*20\\. In reference to the phylogenetic tree", G.tree({n:"A",c:["Swordfish",{n:"B",c:["Frog",{n:"C",c:["Alligator","T. rex"]}]}]},{w:420,lw:110,rowH:32}), "Redrawn from the paper's tree, with nodes A, B and C.");
dg("core2022","^\\s*21\\. Using the phylogenetic tree", G.tree({lab:"Arthropoda",c:[{lab:"Arachnata",c:["Trilobita","Chelicerata"]},{lab:"Mandibulata",c:["Crustacea",{c:["Myriapoda","Insecta"]}]}]},{w:460,lw:110,rowH:32}), "Redrawn from the paper's tree.");
dg("core2022","^\\s*Question 6\\b", G.graph({xmax:360,ymax:10,noscale:1,xlab:"Time (s)",ylab:"Volume of CO₂ (cm³)",vl:[{x:30,t:"30"},{x:300,t:"300"}],
  curves:[{f:x=>8.5*(1-Math.exp(-x/10)),color:"#c2551f",label:"Small pieces",lx:40,ly:9.3},{f:x=>8.5*(1-Math.exp(-x/75)),color:"#2b5ea8",label:"Large pieces",lx:150,ly:6}]}),
  "Redrawn: the small-piece curve rises faster and levels off sooner. Both reach about the same final volume, the large pieces at about 300 s.");
dg("core2022","^\\s*Question 9\\b", (()=>{let s=`<rect x="0" y="0" width="480" height="260" fill="#cfe3f5" fill-opacity=".45" stroke="none"/>`;
  s+=`<path d="M0,0 L300,0 C280,40 250,70 220,110 C205,130 215,150 235,160 L250,175 C262,185 280,190 300,200 L480,180 L480,260 L330,260 C300,230 270,210 245,195 C225,185 200,160 190,140 C175,110 140,80 0,70 Z" fill="#d8c8a0" fill-opacity=".8"/>`;
  s+=G.T(70,30,"North America",{s:12})+G.T(410,240,"South America",{s:12})+G.T(90,190,"Pacific Ocean",{s:13,b:1})+G.T(370,90,"Caribbean Sea",{s:13,b:1})+G.T(250,150,"Isthmus of Panama",{s:11,st:1,a:"start"});
  const fish=(x,y)=>`<path d="M${x},${y} q18,-12 36,0 q-18,12 -36,0 Z M${x+36},${y} l10,-7 l0,14 Z" fill="#f3c440"/>`;
  s+=fish(70,215)+G.T(90,240,"Porkfish (Anisotremus taeniatus)",{s:11,st:1})+fish(350,115)+G.T(380,140,"Porkfish (Anisotremus virginicus)",{s:11,st:1});
  return G.svg(480,260,s);})(), "Redrawn map (simplified): the Isthmus of Panama separates the Pacific porkfish from the Caribbean porkfish.");
dg("core2022","^\\s*g\\) Name the following compounds", "", "The two structural formulas for this question couldn't be redrawn reliably: your two sets of files disagree on the second one. The first is a straight chain of four carbons with only single bonds. Use your printed paper.");
dg("core2022","^\\s*a\\) Complete the following table with either names", "", "The blank tables for this question were images that couldn't be read. From the descriptions, the first lists CaSO₄, zinc oxide, Cu(OH)₂ and sodium carbonate. The ion table includes Mg²⁺ (12 neutrons) and an ion with 17 protons, a charge of −1 and a mass number of 36.");

/* ================= 2022 EXT ================= */
dg("ext2022","^\\s*2\\. A reaction has the energy profile", G.graph({xmax:10,ymax:120,yt:[0,10,20,30,40,50,60,70,80,90,100,110,120],xt:[],xlab:"progress of reaction",ylab:"enthalpy (kJ mol⁻¹)",
  curves:[{pts:[[0,50],[2,50],[3.2,62],[4.5,96],[5,100],[5.5,96],[6.8,52],[8,40],[10,40]]}]}),
  "Redrawn: reactants at about 50 kJ mol⁻¹, a peak at about 100, products at about 40.");
dg("ext2022","^\\s*6\\. Grevy", "", "The map showed where the remaining Grevy's zebra live (scattered areas, mainly in Kenya and Ethiopia, near Somalia), plus a separate introduced population in Tsavo East National Park in southern Kenya.");
