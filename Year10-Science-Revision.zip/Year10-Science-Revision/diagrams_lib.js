// Drawing helpers for redrawn exam diagrams. All drawings use currentColor so they follow light/dark mode.
window.G = (function(){
  const svg = (w,h,body)=>`<svg viewBox="0 0 ${w} ${h}" width="${w}" style="max-width:100%;height:auto" xmlns="http://www.w3.org/2000/svg" font-family="Avenir Next, Gill Sans, Trebuchet MS, sans-serif" font-size="13" fill="none" stroke="currentColor" stroke-width="1.6">${body}</svg>`;
  const T = (x,y,t,o={})=>`<text x="${x}" y="${y}" fill="currentColor" stroke="none" text-anchor="${o.a||"middle"}" font-size="${o.s||13}" ${o.b?'font-weight="700"':''} ${o.r?`transform="rotate(${o.r} ${x} ${y})"`:""} ${o.st?`font-style="italic"`:""}>${t}</text>`;
  const L = (x1,y1,x2,y2,o="")=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" ${o}/>`;
  const C = ["#2b5ea8","#c2551f","#2f7d4f","#8a2c6d"];

  // Line graph. curves: {pts:[[x,y]..]} or {f:x=>y}; opts: xmax,ymax,ymin,xt,yt,xlab,ylab,noscale,vl (vertical guide xs),lab (text marks)
  function graph(o){
    const w=o.w||540,h=o.h||320,l=64,r=24,t=18,b=52,pw=w-l-r,ph=h-t-b, ymin=o.ymin||0;
    const X=x=>l+x/o.xmax*pw, Y=y=>t+ph-(y-ymin)/(o.ymax-ymin)*ph;
    let s="";
    if(!o.noscale){ (o.yt||[]).forEach(v=>{ s+=L(l,Y(v),l+pw,Y(v),'stroke-opacity=".15"')+T(l-8,Y(v)+4,v,{a:"end",s:11}); });
      (o.xt||[]).forEach(v=>{ s+=L(X(v),t+ph,X(v),t+ph+5)+T(X(v),t+ph+19,v,{s:11}); }); }
    (o.vl||[]).forEach(v=>{ s+=L(X(v.x),Y(v.y||ymin),X(v.x),t+ph,'stroke-dasharray="4 4" stroke-opacity=".6"')+T(X(v.x),t+ph+19,v.t,{s:11}); });
    s+=L(l,t,l,t+ph,'stroke-width="2"')+L(l,t+ph,l+pw,t+ph,'stroke-width="2"');
    s+=T(l+pw/2,h-10,o.xlab,{s:12.5})+T(18,t+ph/2,o.ylab,{s:12.5,r:-90});
    o.curves.forEach((c,i)=>{
      let pts=c.pts; if(c.f){pts=[];for(let k=0;k<=100;k++){const x=o.xmax*k/100;pts.push([x,c.f(x)]);}}
      const col=c.color||C[i];
      s+=`<path d="${c.lin?"M"+pts.map(p=>X(p[0])+","+Y(p[1])).join("L"):smooth(pts.map(p=>[X(p[0]),Y(p[1])]))}" stroke="${col}" stroke-width="2.6" ${c.dash?'stroke-dasharray="7 5"':''}/>`;
      if(c.dots) c.pts.forEach(p=>s+=`<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="3" fill="${col}" stroke="none"/>`);
      if(c.label) s+=`<text x="${X(c.lx)}" y="${Y(c.ly)}" fill="${col}" stroke="none" font-size="12.5" font-weight="700" text-anchor="${c.la||"start"}">${c.label}</text>`;
    });
    (o.lab||[]).forEach(m=>s+=T(X(m.x),Y(m.y),m.t,{b:1,a:m.a||"middle"}));
    return svg(w,h,s);
  }
  function smooth(p){ // Catmull-Rom to Bezier
    if(p.length<3) return "M"+p.map(q=>q.join(",")).join("L");
    let d=`M${p[0][0]},${p[0][1]}`;
    for(let i=0;i<p.length-1;i++){const p0=p[i-1]||p[i],p1=p[i],p2=p[i+1],p3=p[i+2]||p2;
      d+=`C${p1[0]+(p2[0]-p0[0])/6},${p1[1]+(p2[1]-p0[1])/6} ${p2[0]-(p3[0]-p1[0])/6},${p2[1]-(p3[1]-p1[1])/6} ${p2[0]},${p2[1]}`;}
    return d;
  }

  // Pedigree. people:{id,x,y,s:'m'|'f',a:affected,n:number label}; couples:[[a,b]]; kids:[{p:[a,b],k:[ids]}]; names:true adds blank boxes
  function pedigree(o){
    const S=26, P={}; o.people.forEach(p=>P[p.id]=p);
    let s="";
    o.couples.forEach(([a,b])=>{ s+=L(P[a].x,P[a].y,P[b].x,P[b].y); });
    o.kids.forEach(k=>{ const [a,b]=k.p, mx=(P[a].x+P[b].x)/2, py=P[a].y, ky=P[k.k[0]].y, bar=ky-S/2-16;
      const xs=k.k.map(id=>P[id].x); s+=L(mx,py,mx,bar)+L(Math.min(...xs,mx),bar,Math.max(...xs,mx),bar);
      k.k.forEach(id=>s+=L(P[id].x,bar,P[id].x,P[id].y-S/2)); });
    o.people.forEach(p=>{ const f=p.a?'fill="currentColor"':'fill="var(--card)"';
      s+= p.s==="m"?`<rect x="${p.x-S/2}" y="${p.y-S/2}" width="${S}" height="${S}" ${f}/>`:p.s==="f"?`<circle cx="${p.x}" cy="${p.y}" r="${S/2}" ${f}/>`:`<rect x="${p.x-S/2.6}" y="${p.y-S/2.6}" width="${S/1.3}" height="${S/1.3}" transform="rotate(45 ${p.x} ${p.y})" ${f}/>`;
      if(p.n!==undefined) s+=T(p.x,p.y+S/2+15,p.n,{s:12,b:1});
      if(o.names) s+=`<foreignObject x="${p.x-38}" y="${p.y+S/2+3}" width="76" height="26">{{IN}}</foreignObject>`;
    });
    if(o.gen) o.gen.forEach(g=>s+=T(16,g.y+5,g.t,{b:1}));
    const lx=o.w-120; s+=`<rect x="${lx}" y="10" width="14" height="14"/>`+T(lx+22,22,"male",{a:"start",s:11.5})+`<circle cx="${lx+7}" cy="41" r="7"/>`+T(lx+22,45,"female",{a:"start",s:11.5})+`<rect x="${lx}" y="57" width="14" height="14" fill="currentColor"/>`+T(lx+22,69,o.key||"affected",{a:"start",s:11.5});
    return svg(o.w,o.h,s);
  }

  // Cladogram. spec: leaf string or {c:[...], n:'node label', t:time}; opts.time: {max, ticks:[...], lab}
  function tree(spec,o={}){
    const leaves=[]; const w=o.w||560, rowH=o.rowH||30, lw=o.lw||150, top=20;
    const height=n=>typeof n==="string"?0:1+Math.max(...n.c.map(height));
    const H=height(spec), x0=20, x1=w-lw-10;
    let s="";
    function place(n,depth){
      if(typeof n==="string"){ const y=top+leaves.length*rowH; leaves.push(n); return {x:x1,y}; }
      const ch=n.c.map(c=>place(c,depth+1));
      const x = o.time? x0+(o.time.max-(n.t||0))/o.time.max*(x1-x0) : x0+(H-height(n))/H*(x1-x0)*0.999;
      const y=(Math.min(...ch.map(c=>c.y))+Math.max(...ch.map(c=>c.y)))/2;
      s+=L(x,Math.min(...ch.map(c=>c.y)),x,Math.max(...ch.map(c=>c.y)));
      ch.forEach(c=>s+=L(x,c.y,c.x,c.y));
      if(n.n) s+=`<circle cx="${x}" cy="${y}" r="10" fill="var(--card)"/>`+T(x,y+4,n.n,{s:11,b:1});
      if(n.lab) s+=T(x+4,y-8,n.lab,{a:"start",s:11.5,st:1});
      return {x,y};
    }
    const root=place(spec,0);
    s+=L(Math.max(x0-14,4),root.y,root.x,root.y);
    if(o.rootLab) s+=T(4,root.y-8,o.rootLab,{a:"start",s:11.5});
    leaves.forEach((n,i)=>s+=T(x1+8,top+i*rowH+4.5,n,{a:"start",st:o.italic}));
    let hgt=top+leaves.length*rowH;
    if(o.time){ const ay=hgt+4; s+=L(x0,ay,x1,ay); o.time.ticks.forEach(v=>{const x=x0+(o.time.max-v)/o.time.max*(x1-x0); s+=L(x,ay,x,ay+5)+T(x,ay+18,v,{s:11});}); s+=T((x0+x1)/2,ay+36,o.time.lab,{s:12}); hgt+=44; }
    return svg(w,hgt+10,s);
  }

  // One cell at a stage, drawn in a 130x130 box. stage: inter|pro|prom|meta|ana|telo|cyto|telo1
  function cell(stage,o={}){
    const c="#c2551f", b="#2b5ea8"; let s="";
    const X=(x,y,col,r=0)=>`<g transform="translate(${x} ${y}) rotate(${r})" stroke="${col}" stroke-width="3.2" stroke-linecap="round"><line x1="-6" y1="-8" x2="6" y2="8"/><line x1="6" y1="-8" x2="-6" y2="8"/></g>`;
    const V=(x,y,col,dir)=>`<path d="M${x-5},${y-dir*8} L${x},${y} L${x+5},${y-dir*8}" stroke="${col}" stroke-width="3" stroke-linecap="round"/>`;
    const cent=(x,y)=>`<g stroke="#b08a00" stroke-width="2.4"><line x1="${x-4}" y1="${y}" x2="${x+4}" y2="${y}"/><line x1="${x}" y1="${y-4}" x2="${x}" y2="${y+4}"/></g>`;
    const spindle=(n=5)=>{let q="";for(let i=0;i<n;i++){const yy=65+(i-(n-1)/2)*11;q+=`<path d="M65,14 Q${30+i*0} ${yy} 65,116" stroke-opacity=".35" stroke-width="1"/>`.replace("Q30",`Q${65+(i-(n-1)/2)*20}`);}return q;};
    if(stage==="cyto"){ s+=`<ellipse cx="65" cy="35" rx="46" ry="28"/><ellipse cx="65" cy="97" rx="46" ry="28"/><circle cx="65" cy="35" r="14" stroke-dasharray="3 2"/><circle cx="65" cy="97" r="14" stroke-dasharray="3 2"/>`; return svg(130,130,s); }
    if(stage==="telo"||stage==="telo1"){ s+=`<path d="M65,6 C120,6 124,58 92,65 C124,72 120,124 65,124 C10,124 6,72 38,65 C6,58 10,6 65,6Z"/>`;
      if(stage==="telo"){ s+=`<circle cx="65" cy="32" r="16" stroke-dasharray="3 2"/><circle cx="65" cy="98" r="16" stroke-dasharray="3 2"/>`+V(58,34,c,1)+V(72,34,b,1)+V(58,96,c,-1)+V(72,96,b,-1); }
      else { s+=X(55,32,c)+X(75,32,b)+X(55,98,c)+X(75,98,b)+cent(65,10)+cent(65,120); }
      return svg(130,130,s); }
    s+=`<circle cx="65" cy="65" r="58"/>`;
    if(stage==="inter"){ s+=`<circle cx="65" cy="65" r="26"/><path d="M50,60 q6,-10 12,0 t12,0 M52,72 q5,6 10,0 t12,2" stroke-width="1.2"/>`+cent(100,30); }
    if(stage==="pro"){ s+=`<circle cx="65" cy="65" r="30" stroke-dasharray="4 4" stroke-opacity=".5"/>`+X(52,55,c,20)+X(78,58,b,-30)+X(58,80,b,60)+X(80,80,c,10)+cent(65,10)+cent(65,120)+spindle(3); }
    if(stage==="prom"){ s+=spindle(5)+X(45,50,c,30)+X(85,48,b,-20)+X(55,85,b,70)+X(82,82,c,10)+cent(65,10)+cent(65,120); }
    if(stage==="meta"){ s+=spindle(5)+X(43,65,c,90)+X(57,65,b,90)+X(71,65,c,90)+X(85,65,b,90)+cent(65,10)+cent(65,120); }
    if(stage==="ana"){ s+=spindle(5)+V(47,32,c,1)+V(60,30,b,1)+V(73,30,c,1)+V(86,32,b,1)+V(47,98,c,-1)+V(60,100,b,-1)+V(73,100,c,-1)+V(86,98,b,-1)+cent(65,10)+cent(65,120); }
    if(stage==="pron"){ s+=`<circle cx="65" cy="65" r="32"/>`+X(52,55,c,20)+X(78,58,b,-30)+X(58,80,b,60)+X(80,80,c,10)+cent(100,22)+cent(30,108); }
    if(o.arrows) o.arrows.forEach(a=>s+=`<line x1="${a[0]}" y1="${a[1]}" x2="${a[2]}" y2="${a[3]}" stroke-width="1.2"/>`);
    if(o.tags){ o.tags.forEach(a=>{ s+=`<line x1="${a[0]}" y1="${a[1]}" x2="${a[2]}" y2="${a[3]}" stroke-width="1.3"/><circle cx="${a[2]}" cy="${a[3]}" r="2.2" fill="currentColor"/>`+T(a[0]+(a[0]>130?6:-6),a[1]+4,a[4],{a:a[0]>130?"start":"end",b:1}); });
      return svg(o.w||210,130,s).replace('viewBox="0 0 '+(o.w||210)+' 130"',`viewBox="${o.x0||0} 0 ${o.w||210} 130"`); }
    return svg(130,130,s);
  }
  function cells(list){ // list: [[stage,label,opts]]
    return `<div class="dgrow">${list.map(([st,lab,op])=>`<div class="dgcell">${cell(st,op||{})}<div class="dglab">${lab}</div></div>`).join("")}</div>`;
  }

  // Karyotype. opt: {sex:'XY'|'XX'|'XXY', tri:n}
  function karyo(o){
    let s="", x=14, y=24; const len=n=>58-n*1.9;
    for(let n=1;n<=24;n++){
      const lab=n<=22?n:(n===23?"X":"Y"); let cnt=2;
      if(n===o.tri) cnt=3;
      if(n===23) cnt=(o.sex.match(/X/g)||[]).length;
      if(n===24) cnt=(o.sex.match(/Y/g)||[]).length;
      if(n===23 && x>14) {}
      const hgt = n===23?len(7):n===24?len(21):len(n);
      for(let k=0;k<cnt;k++){ s+=`<rect x="${x+k*9}" y="${y+60-hgt}" width="6" height="${hgt}" rx="3" fill="currentColor" fill-opacity=".75" stroke="none"/><line x1="${x+k*9}" y1="${y+60-hgt*0.62}" x2="${x+k*9+6}" y2="${y+60-hgt*0.62}" stroke="var(--card)" stroke-width="2"/>`; }
      s+=T(x+Math.max(cnt,1)*4.5-2,y+76,lab,{s:11});
      x+= Math.max(cnt,2)*9+16;
      if(n===12){ x=14; y+=100; }
    }
    return svg(560,215,s);
  }

  const punnett=(r=2,c=2)=>`<table class="dgt punnett"><tr><th></th>${Array(c).fill(0).map(()=>`<th>{{IN}}</th>`).join("")}</tr>${Array(r).fill(0).map(()=>`<tr><th>{{IN}}</th>${Array(c).fill(0).map(()=>`<td>{{IN}}</td>`).join("")}</tr>`).join("")}</table>`;
  const table=(h,rows)=>`<table class="dgt"><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join("")}</tr>`).join("")}</table>`;
  return {svg,T,L,graph,smooth,pedigree,tree,cell,cells,karyo,punnett,table};
})();
