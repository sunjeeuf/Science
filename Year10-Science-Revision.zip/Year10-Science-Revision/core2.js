DATA.core.chem.push(
{id:"kinetic", title:"Kinetic theory & collision theory", group:"Rates of Reaction",
checks:[
 "State the kinetic theory of matter.",
 "State the collision theory."
],
html:`
<ul class="notes">
<li><b>Kinetic theory of matter:</b> all matter is made of tiny particles that are always moving. The more energy (the higher the temperature), the faster they move. Particles vibrate in solids, slide past each other in liquids and move freely in gases.</li>
<li><b>Collision theory:</b> for a reaction to happen, reactant particles must <b>collide</b>, with <b>enough energy</b> (at least the activation energy) and in the <b>right orientation</b>. Only these "successful collisions" form products.</li>
<li>Anything that makes successful collisions <b>more frequent</b> or <b>more energetic</b> increases the reaction rate.</li>
</ul>`,
kw:["kinetic theory of matter","collision theory","successful collision","activation energy"],
cards:[["3 conditions for a successful collision?","Particles collide, with enough energy, in the right orientation."],["Kinetic theory in one line?","All matter is made of moving particles, and they move faster when they have more energy."]]},

{id:"factors", title:"Factors affecting rate of reaction", group:"Rates of Reaction",
checks:[
 "List the factors that control the rate of a chemical reaction: surface area, concentration, temperature, mixing/stirring, catalyst.",
 "Explain how each factor affects the rate of reaction and relate it to collision theory."
],
html:`
<table><tr><th>Factor (increased)</th><th>Effect on rate</th><th>Collision-theory reason</th></tr>
<tr><td>Surface area (powder vs lumps)</td><td>Increases</td><td>More particles are exposed, so there are more collisions per second.</td></tr>
<tr><td>Concentration</td><td>Increases</td><td>More particles in the same volume, so collisions are more frequent.</td></tr>
<tr><td>Temperature</td><td>Increases</td><td>Particles move faster, so they collide more often and more collisions have enough energy.</td></tr>
<tr><td>Mixing / stirring</td><td>Increases</td><td>Reacted particles are moved away and replaced by fresh reactants.</td></tr>
<tr><td>Catalyst (e.g. an enzyme)</td><td>Increases</td><td>Gives an alternative pathway with lower activation energy, so more collisions succeed. The catalyst isn't used up.</td></tr></table>
<h4>Reading rate graphs</h4>
<ul class="notes">
<li>The <b>steepest part</b> (at the start) is the fastest rate, because reactant concentration is highest.</li>
<li>The curve <b>flattens</b> as reactants are used up, and a <b>plateau</b> means the reaction has stopped because a reactant has run out.</li>
<li>A steeper curve that plateaus sooner is a faster reaction. The same final height means the same amount of reactant was used. A higher plateau means more reactant was present.</li>
<li>A mass-of-flask graph goes <b>down</b> because CO₂ gas escapes from the flask.</li>
</ul>
<div class="exam"><b>From past papers</b> Marble chips (CaCO₃) + acid with small vs large pieces: small pieces react faster and reach the same final volume. The silver chloride curves X and Y, with regions A (fastest), B (slowing) and C (finished). H₂O₂ decomposition plateauing at 60 cm³. A matching table (decreased temperature means rate decreases, because there's less energy for collisions).</div>`,
kw:["surface area","concentration","temperature","mixing/stirring","catalyst","enzyme","rate of reaction"],
cards:[["Why does powder react faster than lumps?","Larger surface area, so more collisions per second."],["What does the plateau on a rate graph mean?","The reaction has finished because a reactant ran out."],["How does a catalyst work?","It lowers the activation energy and isn't used up."],["Why does temperature raise the rate?","Faster particles collide more often, and more collisions have enough energy."]]}
);

DATA.core.phys.push(
{id:"thermal", title:"Thermal energy transfer", group:"Thermal Energy",
checks:[
 "Understand the transfer of thermal energy via conduction.",
 "Understand the transfer of thermal energy via convection.",
 "Understand the transfer of thermal energy via radiation (emit and absorb)."
],
html:`
<table><tr><th>Method</th><th>How it works</th><th>Where</th><th>Example</th></tr>
<tr><td><b>Conduction</b></td><td>Vibrating particles bump into their neighbours and pass kinetic energy along. Metals are good conductors because of free electrons.</td><td>Mainly solids</td><td>A metal pot handle getting hot</td></tr>
<tr><td><b>Convection</b></td><td>Heated fluid expands, becomes less dense and rises. Cooler, denser fluid sinks to replace it, which sets up a <b>convection current</b>.</td><td>Liquids and gases</td><td>Water circulating in a heated pot, a hot-air balloon</td></tr>
<tr><td><b>Radiation</b></td><td>Energy moves as infrared waves and needs <b>no particles</b>, so it can cross a vacuum.</td><td>Anywhere, including space</td><td>Sun's heat, warmth felt from a flame</td></tr></table>
<ul class="notes">
<li>Hot objects <b>emit</b> more radiation. <b>Dark, matte</b> surfaces are the best absorbers and emitters, while <b>light, shiny</b> surfaces reflect radiation.</li>
<li><b>Insulators</b> (air, plastic, wool) are poor conductors. Trapped air also stops convection.</li>
</ul>
<div class="exam"><b>From past papers</b> A pot of water over a flame: identify convection currents in the water, conduction along the metal handle and radiation from the flame. Then explain how a hot-air balloon rises (convection: hot air is less dense).</div>`,
kw:["conduction","convection","radiation","emit","absorb","convection current","insulator"],
cards:[["Which transfer needs no particles?","Radiation."],["Why does hot air rise?","It expands and becomes less dense than the cooler air around it."],["Best surface for absorbing radiation?","Dark and matte."]]}
);
